#!/usr/bin/env bash
set -euo pipefail
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle 8.13 is required. Install Gradle or use the GitHub Actions workflow." >&2
  exit 1
fi
gradle --no-daemon :app:assembleDebug
printf '\nAPK created at: %s\n' "$(pwd)/app/build/outputs/apk/debug/app-debug.apk"
