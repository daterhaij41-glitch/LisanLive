package com.lisanlive.app

import android.content.Context
import android.net.Uri
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipInputStream
import kotlin.concurrent.thread

/** Installs the Vosk Turkish model into the app-private files directory. */
object ModelInstaller {
    private const val MODEL_URL = "https://huggingface.co/rhasspy/vosk-models/resolve/main/tr/vosk-model-small-tr-0.3.zip"
    private const val MODEL_DIR_NAME = "vosk-model-small-tr-0.3"
    private const val MAX_ARCHIVE_BYTES = 120L * 1024L * 1024L
    private const val MAX_EXTRACTED_BYTES = 220L * 1024L * 1024L
    private val busy = AtomicBoolean(false)

    fun modelDirectory(context: Context): File = File(context.filesDir, MODEL_DIR_NAME)

    fun isInstalled(context: Context): Boolean {
        val root = modelDirectory(context)
        return validModel(root)
    }

    fun download(context: Context, onProgress: (Int) -> Unit, onComplete: (Result<File>) -> Unit) {
        runInstall(context, onProgress, onComplete) { archive ->
            downloadArchive(archive, onProgress)
        }
    }

    /** Imports a ZIP selected by the user through Android's document picker. */
    fun importZip(context: Context, uri: Uri, onProgress: (Int) -> Unit, onComplete: (Result<File>) -> Unit) {
        runInstall(context, onProgress, onComplete) { archive ->
            context.contentResolver.openInputStream(uri)?.use { input ->
                copyWithLimit(input, archive, MAX_ARCHIVE_BYTES, onProgress)
            } ?: error("تعذّر فتح الملف المختار. اختر ملف ZIP من تطبيق الملفات.")
        }
    }

    private fun runInstall(
        context: Context,
        onProgress: (Int) -> Unit,
        onComplete: (Result<File>) -> Unit,
        acquireArchive: (File) -> Unit
    ) {
        if (!busy.compareAndSet(false, true)) {
            onComplete(Result.failure(IllegalStateException("توجد عملية تجهيز أخرى قيد التنفيذ.")))
            return
        }
        val app = context.applicationContext
        thread(name = "lisan-model-installer") {
            val archive = File(app.cacheDir, "lisan-turkish-model.zip")
            val unpack = File(app.filesDir, "lisan-model-staging")
            val stagedModel = File(app.filesDir, "$MODEL_DIR_NAME-staged")
            val backup = File(app.filesDir, "$MODEL_DIR_NAME-backup")
            try {
                archive.delete()
                unpack.deleteRecursively()
                stagedModel.deleteRecursively()
                unpack.mkdirs()

                acquireArchive(archive)
                require(archive.isFile && archive.length() > 1_000_000L) {
                    "الملف الذي وصلنا أصغر من نموذج Vosk المتوقع؛ قد يكون صفحة خطأ بدلاً من ZIP."
                }
                require(archive.length() <= MAX_ARCHIVE_BYTES) { "حجم ملف النموذج أكبر من الحد المسموح." }
                validateZipSignature(archive)
                extractSafely(archive, unpack, onProgress)

                // Vosk's Turkish small model is an older, flat layout. Newer Vosk models
                // use am/, conf/, and graph/ subfolders. Accept either real layout.
                val extractedRoot = unpack.walkTopDown().firstOrNull {
                    it.isDirectory && validModel(it)
                } ?: error("لم نعثر على بنية نموذج Vosk تركي كاملة. النموذج التركي الصغير يستخدم final.mdl وGr.fst وHCLr.fst مباشرة داخل مجلده.")
                val movedToStaging = extractedRoot.renameTo(stagedModel)
                if (!movedToStaging) extractedRoot.copyRecursively(stagedModel, overwrite = true)
                require(stagedModel.isDirectory) { "تعذّر تجهيز مجلد النموذج بعد فك الضغط." }
                check(validModel(stagedModel)) { "النموذج المستورد لا يطابق بنية Vosk المعروفة." }

                val destination = modelDirectory(app)
                backup.deleteRecursively()
                if (destination.exists() && !destination.renameTo(backup)) {
                    error("تعذّر حفظ النسخة الحالية من النموذج قبل الاستبدال.")
                }
                if (!stagedModel.renameTo(destination)) {
                    // Last-resort copy; keep the backup available until validation succeeds.
                    stagedModel.copyRecursively(destination, overwrite = true)
                }
                if (!validModel(destination)) {
                    destination.deleteRecursively()
                    if (backup.exists()) backup.renameTo(destination)
                    error("فشل التحقق من النموذج بعد تثبيته؛ لم يتم اعتماد الملف.")
                }
                backup.deleteRecursively()
                onProgress(100)
                onComplete(Result.success(destination))
            } catch (e: Exception) {
                val destination = modelDirectory(app)
                if (backup.exists() && !validModel(destination)) {
                    destination.deleteRecursively()
                    backup.renameTo(destination)
                }
                onComplete(Result.failure(IllegalStateException(userFacingError(e), e)))
            } finally {
                archive.delete()
                unpack.deleteRecursively()
                stagedModel.deleteRecursively()
                busy.set(false)
            }
        }
    }

    private fun downloadArchive(destination: File, onProgress: (Int) -> Unit) {
        val connection = (java.net.URI(MODEL_URL).toURL().openConnection() as HttpURLConnection).apply {
            connectTimeout = 30_000
            readTimeout = 180_000
            instanceFollowRedirects = true
            requestMethod = "GET"
            setRequestProperty("User-Agent", "LisanLive-Android/2.2.0")
            setRequestProperty("Accept", "application/zip, application/octet-stream, */*")
        }
        try {
            connection.connect()
            val code = connection.responseCode
            if (code !in 200..299) {
                val serverMessage = try {
                    (connection.errorStream ?: connection.inputStream).bufferedReader().use { it.readText().take(180) }
                } catch (_: Exception) { "" }
                error("خادم تنزيل النموذج أعاد HTTP $code ${serverMessage.trim()}")
            }
            val length = connection.contentLengthLong
            if (length > MAX_ARCHIVE_BYTES) error("حجم النموذج من الخادم أكبر من الحد المسموح.")
            val stream = connection.inputStream
            stream.use { input -> copyWithLimit(input, destination, MAX_ARCHIVE_BYTES, onProgress, length) }
        } finally {
            connection.disconnect()
        }
    }

    private fun copyWithLimit(
        input: InputStream,
        destination: File,
        limit: Long,
        onProgress: (Int) -> Unit,
        expectedLength: Long = -1L
    ) {
        destination.parentFile?.mkdirs()
        var total = 0L
        BufferedInputStream(input).use { source ->
            FileOutputStream(destination).use { output ->
                val buffer = ByteArray(64 * 1024)
                while (true) {
                    val read = source.read(buffer)
                    if (read < 0) break
                    total += read
                    require(total <= limit) { "تجاوز ملف النموذج الحد الأقصى للحجم المسموح." }
                    output.write(buffer, 0, read)
                    if (expectedLength > 0L) {
                        onProgress(((total * 35L / expectedLength).toInt()).coerceIn(1, 35))
                    } else {
                        // Indeterminate sources still provide visible feedback.
                        onProgress((1 + (total / (1024L * 1024L)).toInt()).coerceAtMost(35))
                    }
                }
                output.fd.sync()
            }
        }
    }

    private fun validateZipSignature(file: File) {
        val signature = ByteArray(4)
        file.inputStream().use { input ->
            require(input.read(signature) == 4 && signature[0] == 'P'.code.toByte() &&
                signature[1] == 'K'.code.toByte() && signature[2] == 3.toByte() && signature[3] == 4.toByte()) {
                "الملف المختار ليس ZIP صالحاً. تأكد أنك اخترت vosk-model-small-tr-0.3.zip وليس ملف HTML أو صفحة ويب."
            }
        }
    }

    private fun extractSafely(archive: File, destination: File, onProgress: (Int) -> Unit) {
        val canonicalRoot = destination.canonicalPath + File.separator
        var expanded = 0L
        var entries = 0
        ZipInputStream(archive.inputStream().buffered()).use { zip ->
            val buffer = ByteArray(64 * 1024)
            var entry = zip.nextEntry
            while (entry != null) {
                entries++
                require(entries <= 20_000) { "أرشيف النموذج يحتوي عدداً غير طبيعي من الملفات." }
                val name = entry.name.replace('\\', '/')
                require(name.isNotBlank() && !name.startsWith("/") && !name.contains("../") && name != "..") {
                    "يحتوي ZIP على مسار ملف غير آمن."
                }
                val target = File(destination, name)
                require(target.canonicalPath.startsWith(canonicalRoot)) { "رفضنا مساراً غير آمن داخل ملف ZIP." }
                if (entry.isDirectory) {
                    target.mkdirs()
                } else {
                    target.parentFile?.mkdirs()
                    FileOutputStream(target).use { output ->
                        while (true) {
                            val read = zip.read(buffer)
                            if (read < 0) break
                            expanded += read
                            require(expanded <= MAX_EXTRACTED_BYTES) { "الحجم بعد فك الضغط أكبر من الحد المسموح." }
                            output.write(buffer, 0, read)
                        }
                    }
                }
                zip.closeEntry()
                onProgress((35 + (expanded / (8L * 1024L * 1024L)).toInt()).coerceAtMost(90))
                entry = zip.nextEntry
            }
        }
        require(entries > 0) { "ملف ZIP فارغ أو تالف." }
    }

    private fun validModel(root: File): Boolean {
        if (!root.isDirectory) return false

        // V1 is the exact legacy layout shipped by vosk-model-small-tr-0.3:
        // final.mdl + mfcc.conf at the root, with either one HCLG graph or HCLr + Gr.
        val legacyAcoustic = File(root, "final.mdl")
        val legacyMfcc = File(root, "mfcc.conf")
        val legacyFbank = File(root, "fbank.conf")
        val legacyHclg = File(root, "HCLG.fst")
        val legacyHclr = File(root, "HCLr.fst")
        val legacyGr = File(root, "Gr.fst")
        val legacyDisambig = File(root, "disambig_tid.int")
        val legacyFeaturesOk = (legacyMfcc.isFile && legacyMfcc.length() > 0L) ||
            (legacyFbank.isFile && legacyFbank.length() > 0L)
        val legacyGraphOk = (legacyHclg.isFile && legacyHclg.length() > 1024L) ||
            (legacyHclr.isFile && legacyHclr.length() > 1024L &&
                legacyGr.isFile && legacyGr.length() > 1024L &&
                legacyDisambig.isFile && legacyDisambig.length() > 0L)
        val legacy = legacyAcoustic.isFile && legacyAcoustic.length() > 1024L &&
            legacyFeaturesOk && legacyGraphOk

        // V2 is the modern layout: am/, conf/, and graph/.
        val modernAcoustic = File(root, "am/final.mdl")
        val modernModelConfig = File(root, "conf/model.conf")
        val modernMfcc = File(root, "conf/mfcc.conf")
        val modernFbank = File(root, "conf/fbank.conf")
        val modernHclg = File(root, "graph/HCLG.fst")
        val modernHclr = File(root, "graph/HCLr.fst")
        val modernGr = File(root, "graph/Gr.fst")
        val modernDisambig = File(root, "graph/disambig_tid.int")
        val modernFeaturesOk = (modernMfcc.isFile && modernMfcc.length() > 0L) ||
            (modernFbank.isFile && modernFbank.length() > 0L)
        val modernGraphOk = (modernHclg.isFile && modernHclg.length() > 1024L) ||
            (modernHclr.isFile && modernHclr.length() > 1024L &&
                modernGr.isFile && modernGr.length() > 1024L &&
                modernDisambig.isFile && modernDisambig.length() > 0L)
        val modern = modernAcoustic.isFile && modernAcoustic.length() > 1024L &&
            modernModelConfig.isFile && modernModelConfig.length() > 0L &&
            modernFeaturesOk && modernGraphOk

        return legacy || modern
    }

    private fun userFacingError(error: Exception): String {
        val message = error.message?.takeIf { it.isNotBlank() } ?: error.javaClass.simpleName
        return when (error) {
            is java.net.UnknownHostException -> "لا يوجد اتصال بالإنترنت أو تعذّر الوصول إلى خادم النموذج. $message"
            is java.net.SocketTimeoutException -> "انتهت مهلة تنزيل النموذج. جرّب شبكة أكثر استقراراً أو استورد ملف ZIP من التنزيلات."
            else -> message
        }
    }
}
