package com.lisanlive.app

import android.content.Context
import android.net.Uri
import android.os.StatFs
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/** Copies a whisper.cpp GGML model selected with Android's document picker. */
object WhisperModelInstaller {
    private const val MODEL_FILE = "ggml-whisper-large-v3-turkish-general-q5_0.bin"
    private const val MIN_MODEL_BYTES = 900L * 1024L * 1024L
    private const val MAX_MODEL_BYTES = 2L * 1024L * 1024L * 1024L
    private const val EXPECTED_SHA256 = "d4c8894a0c46c0ee5ef067ae981b415c7683721c52b2bc54308895a8f7f240eb"
    private val busy = AtomicBoolean(false)

    fun modelFile(context: Context): File = File(context.filesDir, MODEL_FILE)

    fun isInstalled(context: Context): Boolean {
        val file = modelFile(context)
        return file.isFile && file.length() in MIN_MODEL_BYTES..MAX_MODEL_BYTES
    }

    fun importModel(
        context: Context,
        uri: Uri,
        onProgress: (Int) -> Unit,
        onComplete: (Result<File>) -> Unit
    ) {
        if (!busy.compareAndSet(false, true)) {
            onComplete(Result.failure(IllegalStateException("توجد عملية تجهيز نموذج أخرى قيد التنفيذ.")))
            return
        }
        val app = context.applicationContext
        thread(name = "lisan-whisper-import") {
            val target = modelFile(app)
            val temporary = File(app.filesDir, "$MODEL_FILE.part")
            try {
                val expected = try {
                    app.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length }
                } catch (_: Exception) { null } ?: -1L
                if (expected > MAX_MODEL_BYTES) error("حجم الملف أكبر من الحد المسموح.")
                val required = if (expected > 0) expected else MIN_MODEL_BYTES
                val available = StatFs(app.filesDir.absolutePath).availableBytes
                if (available < required + 128L * 1024L * 1024L) {
                    error("المساحة الفارغة غير كافية لنسخ نموذج Whisper. وفر مساحة تزيد على 1.2 GB ثم أعد المحاولة.")
                }
                temporary.delete()
                val input = app.contentResolver.openInputStream(uri)
                    ?: error("تعذّر فتح الملف المختار. اختر ملف BIN من مجلد Downloads.")
                var total = 0L
                val digest = MessageDigest.getInstance("SHA-256")
                BufferedInputStream(input).use { source ->
                    FileOutputStream(temporary).use { output ->
                        val buffer = ByteArray(256 * 1024)
                        while (true) {
                            val count = source.read(buffer)
                            if (count < 0) break
                            total += count
                            if (total > MAX_MODEL_BYTES) error("حجم الملف أكبر من الحد المسموح.")
                            digest.update(buffer, 0, count)
                            output.write(buffer, 0, count)
                            if (expected > 0) onProgress(((total * 100L) / expected).toInt().coerceIn(0, 99))
                        }
                        output.fd.sync()
                    }
                }
                require(total in MIN_MODEL_BYTES..MAX_MODEL_BYTES) {
                    "حجم الملف غير مطابق لنموذج Whisper Large-v3 Q5 المتوقع. لم يتم تثبيته."
                }
                val actualSha256 = digest.digest().joinToString("") { "%02x".format(it.toInt() and 0xff) }
                require(actualSha256.equals(EXPECTED_SHA256, ignoreCase = true)) {
                    "بصمة الملف لا تطابق نموذج Whisper الأصلي؛ قد يكون التنزيل ناقصاً أو تالفاً. لم يتم تثبيته."
                }
                if (target.exists() && !target.delete()) error("تعذّر استبدال نسخة Whisper السابقة.")
                if (!temporary.renameTo(target)) {
                    temporary.copyTo(target, overwrite = true)
                    temporary.delete()
                }
                require(target.isFile && target.length() == total) { "فشل التحقق من الملف بعد نسخه." }
                onProgress(100)
                onComplete(Result.success(target))
            } catch (e: Exception) {
                temporary.delete()
                onComplete(Result.failure(e))
            } finally {
                busy.set(false)
            }
        }
    }
}
