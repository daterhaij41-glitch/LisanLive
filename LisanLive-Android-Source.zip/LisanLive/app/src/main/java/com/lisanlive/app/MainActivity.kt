package com.lisanlive.app

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    companion object {
        private const val REQUEST_AUDIO = 8101
        private const val REQUEST_PROJECTION = 8102
        private const val REQUEST_OVERLAY = 8103
    }

    private val bg = Color.rgb(11, 18, 32)
    private val panel = Color.rgb(20, 31, 49)
    private val teal = Color.rgb(53, 208, 177)
    private val soft = Color.rgb(159, 177, 197)
    private lateinit var modelButton: Button
    private lateinit var playbackButton: Button
    private lateinit var micButton: Button
    private lateinit var overlayButton: Button
    private lateinit var stopButton: Button
    private lateinit var pauseButton: Button
    private var pausedByUser = false
    private var sessionActive = false
    private lateinit var statusView: TextView
    private lateinit var sourceView: TextView
    private lateinit var translatedView: TextView
    private lateinit var historyView: TextView
    private lateinit var modelProgress: ProgressBar
    private lateinit var modelInfo: TextView
    private var pendingMode = ""
    private var currentTranslation = ""
    private var receiverRegistered = false

    private val updates = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != LiveTranslateService.ACTION_UPDATE) return
            val status = intent.getStringExtra("status").orEmpty()
            val source = intent.getStringExtra("source").orEmpty()
            val translated = intent.getStringExtra("translated").orEmpty()
            if (intent.getBooleanExtra("stopped", false)) setSessionUi(false)
            if (status.isNotBlank()) statusView.text = status
            if (source.isNotBlank()) sourceView.text = source
            if (translated.isNotBlank()) {
                currentTranslation = translated
                translatedView.text = translated
                refreshHistory()
            } else if (source.isNotBlank() && translatedView.text.isNullOrBlank()) {
                translatedView.text = "يتم تجهيز الترجمة…"
            }
            val active = status.contains("يستمع") || status.contains("عاد الاستماع") || status.contains("ترجمة مباشرة")
            if (active) setSessionUi(true)
            if (status.contains("متوقف مؤقتاً")) setSessionUi(true)
            if (status.contains("متوقف مؤقتاً")) { pausedByUser = true; pauseButton.text = "استئناف" }
            if (status.contains("عاد الاستماع") || status.contains("يستمع")) { pausedByUser = false; pauseButton.text = "إيقاف مؤقت" }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildScreen()
        refreshModelUi()
        refreshHistory()
        requestNotificationPermissionIfNeeded()
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(LiveTranslateService.ACTION_UPDATE)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(updates, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(updates, filter)
        }
        receiverRegistered = true
        refreshOverlayUi()
        setSessionUi(getSharedPreferences("lisan_live", MODE_PRIVATE).getBoolean("capture_active", false))
        refreshHistory()
    }

    override fun onResume() {
        super.onResume()
        refreshOverlayUi()
    }

    override fun onStop() {
        if (receiverRegistered) {
            try { unregisterReceiver(updates) } catch (_: Exception) { }
            receiverRegistered = false
        }
        super.onStop()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(bg)
            isFillViewport = true
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(34))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        scroll.addView(page)

        val brand = text("لسان", 32f, Color.WHITE, true).apply { gravity = Gravity.END }
        page.addView(brand, matchWrap())
        page.addView(text("LISAN LIVE  •  TÜRKÇE → العربية", 11f, teal, true).apply { gravity = Gravity.END }, matchWrap())
        page.addView(space(8))
        page.addView(text("ترجمة الكلام التركي مباشرة أثناء مشاهدة الفيديوهات والبثوث", 17f, soft, false).apply {
            gravity = Gravity.END
            setLineSpacing(dp(3).toFloat(), 1.0f)
        }, matchWrap())
        page.addView(space(22))

        val modelCard = card()
        modelCard.addView(text("1  •  تجهيز محرك اللغة التركية", 17f, Color.WHITE, true), matchWrap())
        modelInfo = text("يحتاج إلى تنزيل نموذج صوتي مرة واحدة (حوالي 35 MB). بعد ذلك يتعرف على التركية دون اتصال.", 13f, soft, false).apply {
            gravity = Gravity.END
            setLineSpacing(dp(2).toFloat(), 1.0f)
        }
        modelCard.addView(modelInfo, matchWrap())
        modelProgress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            progressTintList = android.content.res.ColorStateList.valueOf(teal)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(42, 56, 76))
            visibility = View.GONE
        }
        modelCard.addView(modelProgress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(7)).apply { topMargin = dp(12) })
        modelButton = button("تحميل نموذج التركية", teal, bg) { downloadModel() }
        modelCard.addView(modelButton, matchWidthWithTop(12))
        page.addView(modelCard, matchWidth())
        page.addView(space(18))

        val captureCard = card()
        captureCard.addView(text("2  •  ابدأ الترجمة", 17f, Color.WHITE, true), matchWrap())
        captureCard.addView(text("اختر الطريقة المناسبة. ابدأ الالتقاط قبل الرجوع إلى الفيديو.", 13f, soft, false).apply {
            gravity = Gravity.END
        }, matchWrap())
        playbackButton = button("التقاط صوت الفيديو مباشرة  ·  الأفضل", teal, bg) { requestStart("playback") }
        captureCard.addView(playbackButton, matchWidthWithTop(14))
        micButton = button("وضع الميكروفون  ·  بديل", Color.rgb(47, 66, 91), Color.WHITE) { requestStart("microphone") }
        captureCard.addView(micButton, matchWidthWithTop(10))
        overlayButton = button("تفعيل الترجمة العائمة فوق الفيديو", Color.rgb(47, 66, 91), Color.WHITE) { requestOverlayPermission() }
        captureCard.addView(overlayButton, matchWidthWithTop(10))
        val note = text(
            "ملاحظة: الالتقاط المباشر يعمل فقط عندما يسمح تطبيق الفيديو بتسجيل صوته. إذا كان البث محمياً، جرّب وضع الميكروفون مع تشغيل الصوت من مكبر الهاتف.",
            12f, soft, false
        ).apply { gravity = Gravity.END; setLineSpacing(dp(3).toFloat(), 1f) }
        captureCard.addView(note, matchWidthWithTop(12))
        page.addView(captureCard, matchWidth())
        page.addView(space(18))

        val liveCard = card()
        liveCard.addView(text("الترجمة المباشرة", 17f, Color.WHITE, true), matchWrap())
        statusView = text("جاهز. حمّل نموذج التركية للبدء.", 12f, teal, true).apply { gravity = Gravity.END }
        liveCard.addView(statusView, matchWidthWithTop(8))
        liveCard.addView(space(8))
        liveCard.addView(text("النص التركي", 11f, soft, true), matchWrap())
        sourceView = text("سيظهر الكلام التركي هنا…", 14f, Color.LTGRAY, false).apply {
            gravity = Gravity.END
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            setPadding(0, dp(6), 0, dp(10))
        }
        liveCard.addView(sourceView, matchWrap())
        val divider = View(this).apply { setBackgroundColor(Color.rgb(47, 66, 91)) }
        liveCard.addView(divider, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)))
        liveCard.addView(space(10))
        liveCard.addView(text("الترجمة العربية", 11f, teal, true), matchWrap())
        translatedView = text("الترجمة العربية ستظهر هنا…", 25f, Color.WHITE, true).apply {
            gravity = Gravity.END
            textDirection = View.TEXT_DIRECTION_RTL
            setLineSpacing(dp(4).toFloat(), 1.05f)
            setPadding(0, dp(7), 0, dp(10))
            setTextIsSelectable(true)
        }
        liveCard.addView(translatedView, matchWrap())
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        val copyButton = button("نسخ الترجمة", Color.rgb(47, 66, 91), Color.WHITE) { copyTranslation() }
        controls.addView(copyButton, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(5) })
        pauseButton = button("إيقاف مؤقت", Color.rgb(47, 66, 91), Color.WHITE) { togglePause() }.apply { isEnabled = false }
        controls.addView(pauseButton, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(5); marginEnd = dp(5) })
        stopButton = button("إيقاف", Color.rgb(126, 52, 63), Color.WHITE) { stopCapture() }.apply { isEnabled = false }
        controls.addView(stopButton, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(5) })
        liveCard.addView(controls, matchWidthWithTop(8))
        page.addView(liveCard, matchWidth())
        page.addView(space(18))

        val historyCard = card()
        val historyHeader = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_LTR; gravity = Gravity.CENTER_VERTICAL }
        val clear = button("مسح", Color.rgb(47, 66, 91), Color.WHITE) { clearHistory() }
        historyHeader.addView(clear, LinearLayout.LayoutParams(dp(64), dp(38)))
        historyHeader.addView(text("آخر الترجمات", 16f, Color.WHITE, true).apply { gravity = Gravity.END }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        historyCard.addView(historyHeader, matchWidth())
        historyView = text("لا توجد ترجمات محفوظة بعد.", 13f, soft, false).apply { gravity = Gravity.END; setLineSpacing(dp(3).toFloat(), 1f) }
        historyCard.addView(historyView, matchWidthWithTop(10))
        page.addView(historyCard, matchWidth())
        page.addView(space(16))
        page.addView(text("الخصوصية: لا نحفظ الصوت ولا نرسله إلى خادم. التعرف على الكلام والترجمة يعملان محلياً بعد تنزيل النموذجين أول مرة.", 11f, soft, false).apply {
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            setLineSpacing(dp(3).toFloat(), 1f)
        }, matchWidth())
        setContentView(scroll)
    }

    private fun downloadModel() {
        modelButton.isEnabled = false
        modelButton.text = "جارٍ التحميل…"
        modelProgress.visibility = View.VISIBLE
        statusView.text = "يتم تنزيل نموذج التركية…"
        ModelInstaller.download(this, { progress ->
            runOnUiThread { modelProgress.progress = progress }
        }) { result ->
            runOnUiThread {
                modelButton.isEnabled = true
                modelProgress.visibility = View.GONE
                if (result.isSuccess) {
                    modelButton.text = "نموذج التركية جاهز ✓"
                    modelButton.isEnabled = false
                    modelInfo.text = "تم تثبيت نموذج التعرف على الكلام. سيتم تنزيل نموذج الترجمة العربية عند أول تشغيل."
                    statusView.text = "اكتمل تجهيز محرك التركية. يمكنك بدء الترجمة."
                    setCaptureButtonsEnabled(true)
                } else {
                    modelButton.text = "إعادة محاولة تحميل النموذج"
                    statusView.text = "فشل التنزيل: ${result.exceptionOrNull()?.message ?: "تحقق من اتصال الإنترنت"}"
                }
            }
        }
    }

    private fun refreshModelUi() {
        val ready = ModelInstaller.isInstalled(this)
        if (ready) {
            modelButton.text = "نموذج التركية جاهز ✓"
            modelButton.isEnabled = false
            modelInfo.text = "تم تثبيت نموذج التعرف على الكلام. سيتم تنزيل نموذج الترجمة العربية عند أول تشغيل."
            setCaptureButtonsEnabled(true)
        } else {
            modelButton.text = "تحميل نموذج التركية"
            modelButton.isEnabled = true
            modelInfo.text = "يحتاج إلى تنزيل نموذج صوتي مرة واحدة (حوالي 35 MB). بعد ذلك يتعرف على التركية دون اتصال."
            setCaptureButtonsEnabled(false)
        }
    }

    private fun setCaptureButtonsEnabled(enabled: Boolean) {
        if (::playbackButton.isInitialized) playbackButton.isEnabled = enabled
        if (::micButton.isInitialized) micButton.isEnabled = enabled
    }

    private fun requestStart(mode: String) {
        if (!ModelInstaller.isInstalled(this)) {
            toast("حمّل نموذج التركية أولاً")
            return
        }
        pendingMode = mode
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = permissions.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), REQUEST_AUDIO)
        else continueStart()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_AUDIO) {
            val audioGranted = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            if (!audioGranted) {
                toast("يجب السماح باستخدام الميكروفون/الصوت لتشغيل الترجمة")
                return
            }
            continueStart()
        }
    }

    private fun continueStart() {
        if (pendingMode == "playback") {
            val manager = getSystemService(MediaProjectionManager::class.java)
            startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_PROJECTION)
        } else if (pendingMode == "microphone") {
            val intent = Intent(this, LiveTranslateService::class.java).setAction(LiveTranslateService.ACTION_START_MIC)
            startForegroundService(intent)
            setSessionUi(true)
            statusView.text = "يتم تشغيل وضع الميكروفون…"
        }
    }

    @Deprecated("Android screen-capture consent result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_PROJECTION) {
            if (resultCode == RESULT_OK && data != null) {
                val intent = Intent(this, LiveTranslateService::class.java)
                    .setAction(LiveTranslateService.ACTION_START_PLAYBACK)
                    .putExtra(LiveTranslateService.EXTRA_RESULT_CODE, resultCode)
                    .putExtra(LiveTranslateService.EXTRA_PROJECTION_DATA, data)
                startForegroundService(intent)
                setSessionUi(true)
                statusView.text = "يتم تشغيل الالتقاط المباشر…"
            } else {
                statusView.text = "لم تمنح إذن التقاط صوت الفيديو. جرّب وضع الميكروفون."
            }
        } else if (requestCode == REQUEST_OVERLAY) {
            refreshOverlayUi()
        }
    }

    private fun requestOverlayPermission() {
        if (Settings.canDrawOverlays(this)) {
            toast("الترجمة العائمة مفعّلة. ابدأ جلسة ترجمة لتظهر فوق الفيديو.")
            refreshOverlayUi()
            return
        }
        val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        startActivityForResult(intent, REQUEST_OVERLAY)
    }

    private fun refreshOverlayUi() {
        if (!::overlayButton.isInitialized) return
        overlayButton.text = if (Settings.canDrawOverlays(this)) "الترجمة العائمة مفعّلة ✓" else "تفعيل الترجمة العائمة فوق الفيديو"
    }

    private fun setSessionUi(active: Boolean) {
        sessionActive = active
        if (::stopButton.isInitialized) stopButton.isEnabled = active
        if (::pauseButton.isInitialized) pauseButton.isEnabled = active
        if (::playbackButton.isInitialized) playbackButton.isEnabled = !active && ModelInstaller.isInstalled(this)
        if (::micButton.isInitialized) micButton.isEnabled = !active && ModelInstaller.isInstalled(this)
        if (!active && ::pauseButton.isInitialized) {
            pausedByUser = false
            pauseButton.text = "إيقاف مؤقت"
        }
    }

    private fun togglePause() {
        val action = if (pausedByUser) LiveTranslateService.ACTION_RESUME else LiveTranslateService.ACTION_PAUSE
        startService(Intent(this, LiveTranslateService::class.java).setAction(action))
        pausedByUser = !pausedByUser
        pauseButton.text = if (pausedByUser) "استئناف" else "إيقاف مؤقت"
    }

    private fun stopCapture() {
        val intent = Intent(this, LiveTranslateService::class.java).setAction(LiveTranslateService.ACTION_STOP)
        startService(intent)
        statusView.text = "تم إيقاف الترجمة."
        setSessionUi(false)
    }

    private fun copyTranslation() {
        if (currentTranslation.isBlank()) {
            toast("لا توجد ترجمة لنسخها بعد")
            return
        }
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Lisan Arabic translation", currentTranslation))
        toast("تم نسخ الترجمة")
    }

    private fun refreshHistory() {
        if (!::historyView.isInitialized) return
        val array = try { org.json.JSONArray(getSharedPreferences("lisan_live", MODE_PRIVATE).getString("history", "[]")) }
        catch (_: Exception) { org.json.JSONArray() }
        if (array.length() == 0) {
            historyView.text = "لا توجد ترجمات محفوظة بعد."
            return
        }
        val latest = array.optJSONObject(0)
        if (latest != null) {
            currentTranslation = latest.optString("ar", currentTranslation)
            if (::translatedView.isInitialized && translatedView.text == "الترجمة العربية ستظهر هنا…") translatedView.text = currentTranslation
            if (::sourceView.isInitialized && sourceView.text == "سيظهر الكلام التركي هنا…") sourceView.text = latest.optString("tr", "")
        }
        val builder = StringBuilder()
        for (i in 0 until minOf(array.length(), 5)) {
            val item = array.optJSONObject(i) ?: continue
            if (i > 0) builder.append("\n\n──────────\n\n")
            builder.append(item.optString("ar"))
            builder.append("\n")
            builder.append(item.optString("tr"))
        }
        historyView.text = builder.toString()
    }

    private fun clearHistory() {
        getSharedPreferences("lisan_live", MODE_PRIVATE).edit().remove("history").apply()
        refreshHistory()
        toast("تم مسح سجل الترجمات")
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 9001)
        }
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = rounded(panel, 22, Color.rgb(39, 56, 78), 1)
        layoutDirection = View.LAYOUT_DIRECTION_RTL
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.END
        textDirection = View.TEXT_DIRECTION_FIRST_STRONG
    }

    private fun button(label: String, color: Int, textColor: Int, action: () -> Unit): Button = Button(this).apply {
        text = label
        setTextColor(textColor)
        textSize = 14f
        isAllCaps = false
        typeface = Typeface.DEFAULT_BOLD
        background = rounded(color, 15, color, 0)
        setPadding(dp(12), dp(7), dp(12), dp(7))
        setOnClickListener { action() }
    }

    private fun rounded(color: Int, radiusDp: Int, strokeColor: Int, strokeDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
            if (strokeDp > 0) setStroke(dp(strokeDp), strokeColor)
        }

    private fun space(height: Int): View = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }
    private fun matchWidth(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun matchWrap(): LinearLayout.LayoutParams = matchWidth()
    private fun matchWidthWithTop(top: Int): LinearLayout.LayoutParams = matchWidth().apply { topMargin = dp(top) }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
