package com.lisanlive.app

import android.content.Context
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream
import kotlin.concurrent.thread

object ModelInstaller {
    private const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-tr-0.3.zip"
    private const val MODEL_DIR_NAME = "vosk-model-small-tr-0.3"
    @Volatile private var downloading = false

    fun modelDirectory(context: Context): File = File(context.filesDir, MODEL_DIR_NAME)

    fun isInstalled(context: Context): Boolean =
        File(modelDirectory(context), "am/final.mdl").isFile &&
            File(modelDirectory(context), "conf/model.conf").isFile

    fun download(context: Context, onProgress: (Int) -> Unit, onComplete: (Result<File>) -> Unit) {
        synchronized(this) {
            if (downloading) return
            downloading = true
        }
        thread(name = "turkish-model-installer") {
            val zipFile = File(context.cacheDir, "turkish-model.zip")
            val unpackDir = File(context.filesDir, "turkish-model-unpack")
            try {
                zipFile.delete()
                unpackDir.deleteRecursively()
                unpackDir.mkdirs()

                val connection = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 20_000
                    readTimeout = 60_000
                    instanceFollowRedirects = true
                    setRequestProperty("User-Agent", "LisanLive-Android/1.0")
                }
                try {
                    connection.connect()
                    val length = connection.contentLengthLong
                    BufferedInputStream(connection.inputStream).use { input ->
                        FileOutputStream(zipFile).use { output ->
                            val buffer = ByteArray(64 * 1024)
                            var total = 0L
                            while (true) {
                                val count = input.read(buffer)
                                if (count < 0) break
                                output.write(buffer, 0, count)
                                total += count
                                if (length > 0L) onProgress(((total * 100L) / length).toInt().coerceIn(0, 99))
                            }
                        }
                    }
                } finally {
                    connection.disconnect()
                }

                val canonicalRoot = unpackDir.canonicalPath + File.separator
                ZipInputStream(zipFile.inputStream().buffered()).use { zip ->
                    var entry = zip.nextEntry
                    val buffer = ByteArray(32 * 1024)
                    while (entry != null) {
                        val target = File(unpackDir, entry.name)
                        val canonicalTarget = target.canonicalPath
                        require(canonicalTarget.startsWith(canonicalRoot)) { "Invalid model archive entry" }
                        if (entry.isDirectory) {
                            target.mkdirs()
                        } else {
                            target.parentFile?.mkdirs()
                            FileOutputStream(target).use { output ->
                                while (true) {
                                    val count = zip.read(buffer)
                                    if (count < 0) break
                                    output.write(buffer, 0, count)
                                }
                            }
                        }
                        zip.closeEntry()
                        entry = zip.nextEntry
                    }
                }

                val modelFile = unpackDir.walkTopDown().firstOrNull {
                    it.isFile && it.name == "final.mdl" && it.parentFile?.name == "am"
                } ?: error("The downloaded Turkish model is incomplete")
                val extractedRoot = modelFile.parentFile?.parentFile ?: error("Invalid model directory")
                val destination = modelDirectory(context)
                destination.deleteRecursively()
                if (!extractedRoot.renameTo(destination)) {
                    extractedRoot.copyRecursively(destination, overwrite = true)
                    extractedRoot.deleteRecursively()
                }
                check(isInstalled(context)) { "Model verification failed after extraction" }
                onProgress(100)
                onComplete(Result.success(destination))
            } catch (e: Exception) {
                onComplete(Result.failure(e))
            } finally {
                zipFile.delete()
                unpackDir.deleteRecursively()
                synchronized(this) { downloading = false }
            }
        }
    }
}
