package com.lisanlive.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/** Whisper Large V3 Turkish transcription + Qwen 3.8 27B contextual Turkish-to-Arabic translation. */
object GroqTranslator {
    private const val BASE_URL = "https://api.groq.com/openai/v1"
    private const val TRANSCRIPTION_MODEL = "whisper-large-v3"
    private const val TRANSLATION_MODEL = "qwen/qwen3.8-27b"

    fun translate(apiKey: String, turkish: String, previousTurkish: List<String> = emptyList()): String {
        require(apiKey.isNotBlank()) { "أدخل مفتاح Groq أولاً" }
        require(turkish.isNotBlank()) { "النص التركي فارغ" }
        val prompt = buildString {
            append("أنت مترجم محترف للحوارات التركية إلى العربية الفصحى الطبيعية. ترجم المعنى والسياق لا الكلمات منفردة. ")
            append("صحح أخطاء التعرف الصوتي الواضحة فقط عندما يؤيدها السياق، ولا تخترع معلومات. حافظ على الأسماء والضمائر والنبرة. ")
            append("اجعل النتيجة قصيرة وسلسة لتظهر كترجمة على فيديو. أخرج الترجمة العربية فقط دون شرح أو عنوان أو علامات اقتباس.\n\n")
            val context = previousTurkish.takeLast(4).filter { it.isNotBlank() }
            if (context.isNotEmpty()) {
                append("سياق الحوار التركي السابق للفهم فقط؛ لا تعِد ترجمته:\n")
                append(context.joinToString("\n"))
                append("\n\n")
            }
            append("الجملة الحالية المطلوب ترجمتها:\n")
            append(turkish.trim())
        }
        return chat(apiKey, prompt)
    }

    /** Sends an explicitly consented audio segment to Whisper, then translates its corrected transcript. */
    fun transcribeAndTranslate(
        apiKey: String,
        pcm16Mono16k: ByteArray,
        voskHint: String,
        previousTurkish: List<String> = emptyList()
    ): Pair<String, String> {
        require(apiKey.isNotBlank()) { "أدخل مفتاح Groq أولاً" }
        require(pcm16Mono16k.size >= 8_000) { "مقطع الصوت قصير جداً" }
        require(pcm16Mono16k.size <= 1_500_000) { "مقطع الصوت أطول من الحد الآمن" }
        val whisperPrompt = buildString {
            append("Turkish TV or film dialogue, natural spoken Turkish, proper names. ")
            val context = previousTurkish.takeLast(3).filter { it.isNotBlank() }
            if (context.isNotEmpty()) append("Previous Turkish context: ${context.joinToString("; ")}. ")
            if (voskHint.isNotBlank()) append("Possible transcript hint, may be incorrect: ${voskHint.take(300)}")
        }
        val turkish = transcribe(apiKey, pcmToWav(pcm16Mono16k), whisperPrompt).trim()
        if (turkish.isBlank()) throw IOException("لم يتمكن Whisper من استخراج كلام واضح من الصوت.")
        return turkish to translate(apiKey, turkish, previousTurkish)
    }

    private fun transcribe(apiKey: String, wav: ByteArray, prompt: String): String {
        val boundary = "----LisanLive-${UUID.randomUUID()}"
        val connection = (URL("$BASE_URL/audio/transcriptions").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15_000
            readTimeout = 35_000
            doOutput = true
            setRequestProperty("Authorization", "Bearer ${apiKey.trim()}")
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        }
        try {
            connection.outputStream.use { output ->
                fun field(name: String, value: String) {
                    output.write("--$boundary\r\n".toByteArray(Charsets.UTF_8))
                    output.write("Content-Disposition: form-data; name=\"$name\"\r\n\r\n".toByteArray(Charsets.UTF_8))
                    output.write(value.toByteArray(Charsets.UTF_8))
                    output.write("\r\n".toByteArray(Charsets.UTF_8))
                }
                field("model", TRANSCRIPTION_MODEL)
                field("language", "tr")
                field("response_format", "json")
                if (prompt.isNotBlank()) field("prompt", prompt.take(900))
                output.write("--$boundary\r\n".toByteArray(Charsets.UTF_8))
                output.write("Content-Disposition: form-data; name=\"file\"; filename=\"segment.wav\"\r\n".toByteArray(Charsets.UTF_8))
                output.write("Content-Type: audio/wav\r\n\r\n".toByteArray(Charsets.UTF_8))
                output.write(wav)
                output.write("\r\n--$boundary--\r\n".toByteArray(Charsets.UTF_8))
            }
            return JSONObject(readResponse(connection)).optString("text", "")
        } finally {
            connection.disconnect()
        }
    }

    private fun chat(apiKey: String, userPrompt: String): String {
        val request = JSONObject()
            .put("model", TRANSLATION_MODEL)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", userPrompt)))
            .put("temperature", 0.2)
            .put("top_p", 0.8)
            .put("max_completion_tokens", 220)
            .put("reasoning_effort", "none")
        val connection = (URL("$BASE_URL/chat/completions").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 12_000
            readTimeout = 25_000
            doOutput = true
            setRequestProperty("Authorization", "Bearer ${apiKey.trim()}")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        try {
            connection.outputStream.use { it.write(request.toString().toByteArray(Charsets.UTF_8)) }
            val response = JSONObject(readResponse(connection))
            val choices = response.optJSONArray("choices") ?: throw IOException("لم يُرجع Qwen نتيجة ترجمة.")
            val content = choices.optJSONObject(0)?.optJSONObject("message")?.optString("content").orEmpty()
            val translated = content.trim()
                .replace(Regex("^```(?:text)?\\s*|\\s*```$"), "")
                .trim('"', '\'', '«', '»')
            if (translated.isBlank()) throw IOException("عاد رد فارغ من نموذج الترجمة.")
            return translated
        } finally {
            connection.disconnect()
        }
    }

    private fun readResponse(connection: HttpURLConnection): String {
        val status = connection.responseCode
        val body = (if (status in 200..299) connection.inputStream else connection.errorStream)
            ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
        if (status !in 200..299) {
            val message = try { JSONObject(body).optJSONObject("error")?.optString("message").orEmpty() }
            catch (_: Exception) { "" }
            val explanation = when (status) {
                401, 403 -> "مفتاح Groq غير صحيح أو غير مصرح له."
                429 -> "وصلت إلى حد الاستخدام المجاني مؤقتاً؛ سيعود التطبيق إلى الترجمة المحلية."
                413 -> "مقطع الصوت أكبر من الحد المسموح؛ جرّب مقطعاً أقصر."
                else -> message.ifBlank { "تعذّر إكمال الطلب." }
            }
            throw IOException("Groq ($status): $explanation")
        }
        return body
    }

    private fun pcmToWav(pcm: ByteArray): ByteArray {
        val output = ByteArrayOutputStream(44 + pcm.size)
        fun ascii(value: String) { output.write(value.toByteArray(Charsets.US_ASCII)) }
        fun little(value: Int) {
            output.write(value and 0xff)
            output.write((value shr 8) and 0xff)
            output.write((value shr 16) and 0xff)
            output.write((value shr 24) and 0xff)
        }
        ascii("RIFF"); little(36 + pcm.size); ascii("WAVE")
        ascii("fmt "); little(16); output.write(1); output.write(0)
        output.write(1); output.write(0)
        little(16_000); little(32_000)
        output.write(2); output.write(0); output.write(16); output.write(0)
        ascii("data"); little(pcm.size); output.write(pcm)
        return output.toByteArray()
    }
}
