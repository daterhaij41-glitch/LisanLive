# Lisan Live

Native Android app source for live Turkish-to-Arabic captions. Read `README_AR.md` for setup, permissions, limitations, and APK build steps.

- Min Android: 10 / API 29
- JDK: 17
- Android Gradle Plugin: 8.7.3
- Gradle: 8.13
- Compile SDK: 35

The app uses Vosk for offline Turkish speech recognition and Google ML Kit's on-device translation model for Turkish → Arabic. Both language models are downloaded on first use and stored locally.
