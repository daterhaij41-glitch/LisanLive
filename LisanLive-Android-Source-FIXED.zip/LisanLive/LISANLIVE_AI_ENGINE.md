# LisanLive AI engine (3.1.0)

- Cloud Turkish ASR: Groq Whisper Large V3 (`whisper-large-v3`).
- Context-aware Turkish-to-Arabic translation: Groq-hosted Qwen 3.8 27B (`qwen/qwen3.8-27b`).
- The default cloud operation sends transcript text plus a short Turkish context window.
- An explicit opt-in setting sends the audio segment to Whisper for improved Turkish transcription.
- HTTP 429, network errors, and missing credentials fall back to on-device Google ML Kit translation; Vosk remains the on-device ASR engine.
- No Gemini endpoint or model is used.
- Free API usage has published rate limits; the application does not attempt to bypass provider limits.
