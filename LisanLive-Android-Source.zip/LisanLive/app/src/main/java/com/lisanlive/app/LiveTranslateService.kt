package com.lisanlive.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread
import kotlin.math.sqrt

class LiveTranslateService : Service() {
    companion object {
        const val ACTION_START_PLAYBACK = "com.lisanlive.app.START_PLAYBACK"
        const val ACTION_START_MIC = "com.lisanlive.app.START_MIC"
        const val ACTION_STOP = "com.lisanlive.app.STOP"
        const val ACTION_PAUSE = "com.lisanlive.app.PAUSE"
        const val ACTION_RESUME = "com.lisanlive.app.RESUME"
        const val ACTION_UPDATE = "com.lisanlive.app.UPDATE"
        const val ACTION_QUERY_STATUS = "com.lisanlive.app.QUERY_STATUS"
        const val ACTION_REFRESH_OVERLAY = "com.lisanlive.app.REFRESH_OVERLAY"
        const val ACTION_UPDATE_OVERLAY_SETTINGS = "com.lisanlive.app.UPDATE_OVERLAY_SETTINGS"
        const val EXTRA_RESULT_CODE = "projection_result_code"
        const val EXTRA_PROJECTION_DATA = "projection_data"
        const val EXTRA_OVERLAY = "show_overlay"
        private const val CHANNEL_ID = "lisan_live_capture"
        private const val NOTIFICATION_ID = 7441
        private const val SAMPLE_RATE = 16_000
        private const val AUDIO_METER_INTERVAL_MS = 450L
        private const val SILENCE_WARNING_MS = 7_000L
        private const val AUDIO_SIGNAL_THRESHOLD = 1
    }

    private var projection: MediaProjection? = null
    private var audioRecord: AudioRecord? = null
    @Volatile private var voskModel: Model? = null
    @Volatile private var recognizer: Recognizer? = null
    @Volatile private var translator: Translator? = null
    private var captureThread: Thread? = null
    private var overlay: CaptionOverlay? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val running = AtomicBoolean(false)
    private val recognizerLock = Any()
    @Volatile private var preparing = false
    @Volatile private var sessionGeneration = 0
    @Volatile private var paused = false
    @Volatile private var cancelled = false
    @Volatile private var latestPartial = ""
    private val translationExecutor = Executors.newSingleThreadExecutor()
    private var captureMode = ""
    @Volatile private var lastAudioSignalAt = 0L
    @Volatile private var lastAudioLevelSentAt = 0L
    @Volatile private var silenceWarningVisible = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_PLAYBACK -> startPlaybackCapture(intent)
            ACTION_START_MIC -> startMicrophoneCapture()
            ACTION_STOP -> stopEverything()
            ACTION_PAUSE -> pauseCapture()
            ACTION_RESUME -> resumeCapture()
            ACTION_REFRESH_OVERLAY -> {
                if (running.get() || preparing) refreshOverlay()
                else publish("ابدأ جلسة ترجمة أولاً حتى تظهر الترجمة فوق الفيديو.", "", "")
            }
            ACTION_UPDATE_OVERLAY_SETTINGS -> overlay?.refreshSettings()
            ACTION_QUERY_STATUS -> {
                val current = when {
                    preparing -> "جارٍ تجهيز جلسة الترجمة…"
                    running.get() && paused -> "متوقف مؤقتاً"
                    running.get() -> "يستمع الآن"
                    else -> "لا توجد جلسة نشطة"
                }
                publish(current, "", "", running.get() || preparing)
                if (!running.get() && !preparing) stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun startPlaybackCapture(intent: Intent) {
        if (running.get() || preparing) {
            publish("هناك جلسة ترجمة تعمل بالفعل أو يجري تجهيزها. أوقفها أولاً قبل بدء جلسة جديدة.", "", "")
            return
        }
        cancelled = false
        preparing = true
        val generation = ++sessionGeneration
        captureMode = "playback"
        latestPartial = ""
        try {
            startAsForeground("تهيئة التقاط صوت التطبيق…", android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
            val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
            val data = if (Build.VERSION.SDK_INT >= 33) {
                intent.getParcelableExtra(EXTRA_PROJECTION_DATA, Intent::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(EXTRA_PROJECTION_DATA)
            }
            if (data == null || resultCode == 0) error("لم يصل إذن Android لمشاركة صوت التطبيق.")
            val manager = getSystemService(MediaProjectionManager::class.java)
            val activeProjection = manager.getMediaProjection(resultCode, data)
                ?: error("تعذّر إنشاء جلسة التقاط الصوت من Android.")
            projection = activeProjection
            activeProjection.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    if (!cancelled) stopEverything("أوقف Android جلسة التقاط الصوت.")
                }
            }, android.os.Handler(mainLooper))
            prepareTranslationAndAudio(generation)
        } catch (e: Exception) {
            stopEverything("فشل بدء التقاط صوت الفيديو: ${e.message ?: "خطأ غير معروف"}")
        }
    }

    private fun startMicrophoneCapture() {
        if (running.get() || preparing) {
            publish("هناك جلسة ترجمة تعمل بالفعل أو يجري تجهيزها. أوقفها أولاً قبل بدء جلسة جديدة.", "", "")
            return
        }
        cancelled = false
        preparing = true
        val generation = ++sessionGeneration
        captureMode = "microphone"
        latestPartial = ""
        try {
            startAsForeground("تهيئة الاستماع عبر الميكروفون…", android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            prepareTranslationAndAudio(generation)
        } catch (e: Exception) {
            stopEverything("فشل تشغيل الميكروفون: ${e.message ?: "تحقق من الإذن"}")
        }
    }

    private fun startAsForeground(message: String, serviceType: Int) {
        createNotificationChannel()
        val notification = buildNotification(message)
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, notification, serviceType)
        else startForeground(NOTIFICATION_ID, notification)
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LisanLive:AudioCapture").apply {
            setReferenceCounted(false)
            acquire(4 * 60 * 60 * 1000L)
        }
    }

    /** Loads the large acoustic model away from the service main thread. */
    private fun prepareTranslationAndAudio(generation: Int) {
        if (!ModelInstaller.isInstalled(this)) {
            preparing = false
            stopEverything("حمّل نموذج اللغة التركية أولاً من الشاشة الرئيسية.")
            return
        }
        publish("يتم تحميل محرك التركية وتجهيز الترجمة العربية…", "", "", true)
        thread(name = "lisan-model-setup", isDaemon = true) {
            var newModel: Model? = null
            var newRecognizer: Recognizer? = null
            var newTranslator: Translator? = null
            try {
                val modelInstance = Model(ModelInstaller.modelDirectory(this).absolutePath)
                newModel = modelInstance
                val recognizerInstance = Recognizer(modelInstance, SAMPLE_RATE.toFloat())
                newRecognizer = recognizerInstance
                val options = TranslatorOptions.Builder()
                    .setSourceLanguage(TranslateLanguage.TURKISH)
                    .setTargetLanguage(TranslateLanguage.ARABIC)
                    .build()
                val translatorInstance = Translation.getClient(options)
                newTranslator = translatorInstance

                if (cancelled || generation != sessionGeneration) {
                    try { recognizerInstance.close() } catch (_: Exception) { }
                    try { modelInstance.close() } catch (_: Exception) { }
                    try { translatorInstance.close() } catch (_: Exception) { }
                    return@thread
                }

                voskModel = modelInstance
                recognizer = recognizerInstance
                translator = translatorInstance
                translatorInstance.downloadModelIfNeeded(DownloadConditions.Builder().build())
                    .addOnSuccessListener {
                        if (cancelled || generation != sessionGeneration) return@addOnSuccessListener
                        preparing = false
                        startAudioReader()
                    }
                    .addOnFailureListener { error ->
                        if (cancelled || generation != sessionGeneration) return@addOnFailureListener
                        preparing = false
                        stopEverything("تعذّر تنزيل نموذج الترجمة العربية: ${error.message ?: "تحقق من الإنترنت ثم أعد المحاولة"}")
                    }
            } catch (e: Exception) {
                try { newRecognizer?.close() } catch (_: Exception) { }
                try { newModel?.close() } catch (_: Exception) { }
                try { newTranslator?.close() } catch (_: Exception) { }
                android.os.Handler(mainLooper).post {
                    if (!cancelled && generation == sessionGeneration) {
                        preparing = false
                        stopEverything("تعذّر تجهيز محرك الترجمة: ${e.message ?: "خطأ غير معروف"}")
                    }
                }
            }
        }
    }

    private fun startAudioReader() {
        if (cancelled) return
        try {
            val format = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                .build()
            val reportedBuffer = AudioRecord.getMinBufferSize(
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            check(reportedBuffer > 0) { "الهاتف لا يدعم تهيئة الصوت بصيغة 16 kHz المطلوبة." }
            val minBuffer = reportedBuffer.coerceAtLeast(4096)
            audioRecord = if (captureMode == "playback") {
                val activeProjection = projection ?: error("انتهت صلاحية إذن مشاركة صوت التطبيق")
                val config = AudioPlaybackCaptureConfiguration.Builder(activeProjection)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                    .build()
                AudioRecord.Builder()
                    .setAudioFormat(format)
                    .setBufferSizeInBytes(minBuffer * 2)
                    .setAudioPlaybackCaptureConfig(config)
                    .build()
            } else {
                AudioRecord.Builder()
                    .setAudioSource(MediaRecorder.AudioSource.MIC)
                    .setAudioFormat(format)
                    .setBufferSizeInBytes(minBuffer * 2)
                    .build()
            }
            val record = audioRecord ?: error("لم يتم إنشاء مسجل الصوت")
            check(record.state == AudioRecord.STATE_INITIALIZED) { "تعذّر تهيئة مسجل الصوت" }
            record.startRecording()
            running.set(true)
            paused = false
            lastAudioSignalAt = SystemClock.elapsedRealtime()
            lastAudioLevelSentAt = 0L
            silenceWarningVisible = false
            publishAudioLevel(0)
            getSharedPreferences("lisan_live", MODE_PRIVATE).edit().putBoolean("capture_active", true).apply()
            refreshOverlay()
            publish(
                if (captureMode == "playback") "يستمع إلى صوت التطبيق — شغّل البث أو المسلسل الآن" else "يستمع عبر الميكروفون — شغّل الصوت من مكبر الهاتف",
                "",
                "",
                true
            )
            updateNotification("لسان يعمل الآن — التركية إلى العربية")
            val readerGeneration = sessionGeneration
            captureThread = thread(name = "lisan-vosk-audio-$readerGeneration", isDaemon = true) {
                val buffer = ByteArray(4096)
                while (running.get() && readerGeneration == sessionGeneration) {
                    if (paused) {
                        Thread.sleep(100)
                        continue
                    }
                    val count = try { record.read(buffer, 0, buffer.size, AudioRecord.READ_BLOCKING) }
                    catch (_: Exception) { -1 }
                    if (count > 0 && running.get() && readerGeneration == sessionGeneration) {
                        monitorAudioSignal(buffer, count)
                        try {
                            var finalText = ""
                            var partialText = ""
                            synchronized(recognizerLock) {
                                val activeRecognizer = recognizer
                                if (activeRecognizer != null && running.get()) {
                                    if (activeRecognizer.acceptWaveForm(buffer, count)) {
                                        finalText = JSONObject(activeRecognizer.result).optString("text", "").trim()
                                    } else {
                                        partialText = JSONObject(activeRecognizer.partialResult).optString("partial", "").trim()
                                    }
                                }
                            }
                            if (finalText.isNotBlank() && running.get() && readerGeneration == sessionGeneration) {
                                latestPartial = ""
                                translateFinal(finalText, readerGeneration)
                            } else if (partialText.isNotBlank() && partialText != latestPartial && running.get() && readerGeneration == sessionGeneration) {
                                latestPartial = partialText
                                publish("يتم التعرّف على الكلام…", partialText, "")
                            }
                        } catch (e: Exception) {
                            if (running.get()) publish("حدث خطأ أثناء التعرّف على الصوت: ${e.message}", "", "")
                        }
                    } else if (count < 0 && running.get() && readerGeneration == sessionGeneration) {
                        if (paused) continue
                        android.os.Handler(mainLooper).post {
                            stopEverything("انقطع تدفق الصوت. جرّب وضع الميكروفون إذا كان التطبيق يمنع الالتقاط.")
                        }
                        break
                    }
                }
            }
        } catch (e: Exception) {
            stopEverything("لم أستطع الوصول إلى الصوت: ${e.message ?: "تحقق من الأذونات"}")
        }
    }

    /** Measures incoming PCM amplitude so a blocked/silent playback stream is not mistaken for a working capture. */
    private fun monitorAudioSignal(buffer: ByteArray, count: Int) {
        val samples = count / 2
        if (samples <= 0) return
        var sumSquares = 0.0
        var index = 0
        while (index + 1 < count) {
            val low = buffer[index].toInt() and 0xff
            val high = buffer[index + 1].toInt()
            val sample = ((high shl 8) or low).toShort().toInt()
            sumSquares += sample.toDouble() * sample.toDouble()
            index += 2
        }
        val rms = sqrt(sumSquares / samples.toDouble())
        val level = (rms / 327.68).toInt().coerceIn(0, 100)
        val now = SystemClock.elapsedRealtime()
        if (now - lastAudioLevelSentAt >= AUDIO_METER_INTERVAL_MS) {
            lastAudioLevelSentAt = now
            publishAudioLevel(level)
        }
        if (level >= AUDIO_SIGNAL_THRESHOLD) {
            lastAudioSignalAt = now
            if (silenceWarningVisible) {
                silenceWarningVisible = false
                publish("وصل الصوت إلى لسان. جارٍ التعرّف على الكلام…", "", "", true)
            }
        } else if (!silenceWarningVisible && now - lastAudioSignalAt >= SILENCE_WARNING_MS) {
            silenceWarningVisible = true
            val message = if (captureMode == "playback") {
                "لا يصل صوت من التطبيق. قد يمنع البث التقاط الصوت الداخلي؛ أوقف الجلسة وجرّب الميكروفون مع مكبر الهاتف."
            } else {
                "لا يصل صوت إلى الميكروفون. ارفع صوت مكبر الهاتف وقرّب الجهاز من مصدر الصوت."
            }
            publish(message, "", "", true)
        }
    }

    private fun publishAudioLevel(level: Int) {
        sendBroadcast(Intent(ACTION_UPDATE).setPackage(packageName).putExtra("audio_level", level.coerceIn(0, 100)))
    }

    private fun refreshOverlay() {
        if (Settings.canDrawOverlays(this)) {
            if (overlay == null) overlay = CaptionOverlay(this)
            overlay?.refreshSettings()
            overlay?.show()
        } else {
            overlay?.close()
            overlay = null
        }
    }

    private fun translateFinal(source: String, generation: Int) {
        translationExecutor.execute {
            if (cancelled || generation != sessionGeneration) return@execute
            try {
                val task = translator?.translate(source) ?: return@execute
                val translated = Tasks.await(task)
                // A translation task may finish after the user has stopped capture.
                // Do not resurrect a stopped session or append stale history.
                if (cancelled || generation != sessionGeneration) return@execute
                saveHistory(source, translated)
                publish("ترجمة مباشرة", source, translated, true)
            } catch (e: Exception) {
                if (!cancelled && generation == sessionGeneration) {
                    publish("تعذّرت ترجمة هذه الجملة: ${e.message ?: "حاول مجدداً"}", source, "", true)
                }
            }
        }
    }

    private fun saveHistory(source: String, translated: String) {
        val prefs = getSharedPreferences("lisan_live", MODE_PRIVATE)
        val old = try { JSONArray(prefs.getString("history", "[]")) } catch (_: Exception) { JSONArray() }
        val next = JSONArray()
        next.put(JSONObject().put("tr", source).put("ar", translated).put("at", System.currentTimeMillis()))
        for (i in 0 until minOf(old.length(), 39)) next.put(old.getJSONObject(i))
        prefs.edit().putString("history", next.toString()).apply()
    }

    private fun publish(status: String, source: String, translated: String, active: Boolean? = null) {
        val intent = Intent(ACTION_UPDATE).setPackage(packageName)
            .putExtra("status", status)
            .putExtra("source", source)
            .putExtra("translated", translated)
        if (active != null) intent.putExtra("active", active)
        sendBroadcast(intent)
        overlay?.update(source, translated, status)
    }

    private fun pauseCapture() {
        if (!running.get()) return
        paused = true
        try { audioRecord?.stop() } catch (_: Exception) { }
        publishAudioLevel(0)
        publish("متوقف مؤقتاً", "", "", true)
        updateNotification("لسان متوقف مؤقتاً")
    }

    private fun resumeCapture() {
        if (!running.get()) return
        try {
            audioRecord?.startRecording()
            paused = false
            publish("عاد الاستماع", "", "", true)
            updateNotification("لسان يعمل الآن — التركية إلى العربية")
        } catch (e: Exception) {
            publish("تعذّر استئناف الصوت: ${e.message}", "", "")
        }
    }

    private fun stopEverything(finalStatus: String = "تم إيقاف جلسة الترجمة.") {
        cancelled = true
        preparing = false
        sessionGeneration++
        running.set(false)
        getSharedPreferences("lisan_live", MODE_PRIVATE).edit().putBoolean("capture_active", false).apply()
        paused = false
        publishAudioLevel(0)
        try { audioRecord?.stop() } catch (_: Exception) { }
        try { audioRecord?.release() } catch (_: Exception) { }
        audioRecord = null
        val oldRecognizer = recognizer
        recognizer = null
        if (oldRecognizer != null) {
            try { synchronized(recognizerLock) { oldRecognizer.close() } } catch (_: Exception) { }
        }
        try { voskModel?.close() } catch (_: Exception) { }
        voskModel = null
        try { translator?.close() } catch (_: Exception) { }
        translator = null
        try { projection?.stop() } catch (_: Exception) { }
        projection = null
        overlay?.close()
        overlay = null
        try { wakeLock?.release() } catch (_: Exception) { }
        wakeLock = null
        captureThread = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        sendBroadcast(Intent(ACTION_UPDATE).setPackage(packageName).putExtra("status", finalStatus).putExtra("active", false).putExtra("stopped", true))
        stopSelf()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "الترجمة المباشرة", NotificationManager.IMPORTANCE_LOW).apply {
                description = "إشعار جلسة التقاط الصوت والترجمة"
                setShowBadge(false)
            }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(message: String): Notification {
        val stopIntent = Intent(this, LiveTranslateService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(this, 2, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val openIntent = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("لسان | ترجمة تركية إلى عربية")
            .setContentText(message)
            .setContentIntent(openIntent)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "إيقاف", stopPending).build())
            .build()
    }

    private fun updateNotification(message: String) {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildNotification(message))
    }

    override fun onDestroy() {
        if (running.get() || preparing || projection != null || audioRecord != null) stopEverything()
        translationExecutor.shutdownNow()
        super.onDestroy()
    }

    private class CaptionOverlay(private val context: Context) {
        private val window = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        private val prefs = context.getSharedPreferences("lisan_display", Context.MODE_PRIVATE)
        private val mainHandler = android.os.Handler(context.mainLooper)
        private var hideRunnable: Runnable? = null
        private fun dp(value: Int): Int = (value * context.resources.displayMetrics.density).toInt()

        private val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(10), dp(15), dp(13))
            elevation = dp(10).toFloat()
            isClickable = true
        }
        private val dragHandle = TextView(context).apply {
            text = "≡  اسحب لتحريك الترجمة"
            setTextColor(Color.rgb(110, 190, 180))
            textSize = 10f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(4))
            isClickable = true
            isFocusable = false
        }
        private val status = TextView(context).apply {
            text = "لسان • LIVE"
            setTextColor(Color.rgb(110, 231, 183))
            textSize = 10f
            gravity = Gravity.CENTER
            maxLines = 1
        }
        private val source = TextView(context).apply {
            setTextColor(Color.LTGRAY)
            textSize = 12f
            maxLines = 2
            gravity = Gravity.CENTER
            textDirection = View.TEXT_DIRECTION_LTR
            setPadding(0, dp(5), 0, dp(3))
        }
        private val translated = TextView(context).apply {
            setTextColor(Color.WHITE)
            textSize = 22f
            maxLines = 4
            gravity = Gravity.CENTER
            textDirection = View.TEXT_DIRECTION_RTL
            setLineSpacing(dp(2).toFloat(), 1.08f)
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        }
        private var attached = false
        private val params = WindowManager.LayoutParams(
            (context.resources.displayMetrics.widthPixels * 0.92f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(70)
        }

        private var downRawX = 0f
        private var downRawY = 0f
        private var startX = 0
        private var startY = 0

        init {
            container.addView(dragHandle, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            container.addView(status, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            container.addView(source, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            container.addView(translated, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            dragHandle.setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downRawX = event.rawX
                        downRawY = event.rawY
                        startX = params.x
                        startY = params.y
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - downRawX).toInt()
                        val dy = (event.rawY - downRawY).toInt()
                        val maxX = context.resources.displayMetrics.widthPixels / 2
                        params.x = (startX + dx).coerceIn(-maxX, maxX)
                        val isBottom = (params.gravity and Gravity.BOTTOM) == Gravity.BOTTOM
                        params.y = (startY + (if (isBottom) -dy else dy)).coerceAtLeast(dp(8))
                        if (attached) {
                            try { window.updateViewLayout(container, params) } catch (_: Exception) { }
                        }
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        prefs.edit().putInt("overlay_x", params.x).putInt("overlay_y", params.y).apply()
                        true
                    }
                    else -> false
                }
            }
            refreshSettings()
        }

        fun refreshSettings() {
            val fontSize = prefs.getInt("font_size", 22).coerceIn(16, 32)
            val top = prefs.getBoolean("position_top", false)
            val backgroundLevel = prefs.getInt("background_level", 2).coerceIn(0, 2)
            val showSource = prefs.getBoolean("show_source", true)
            val alpha = when (backgroundLevel) {
                0 -> 145
                1 -> 195
                else -> 232
            }
            translated.textSize = fontSize.toFloat()
            source.visibility = if (showSource) View.VISIBLE else View.GONE
            params.gravity = if (top) Gravity.TOP or Gravity.CENTER_HORIZONTAL else Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            params.x = prefs.getInt("overlay_x", 0)
            params.y = prefs.getInt("overlay_y", dp(if (top) 82 else 70)).coerceAtLeast(dp(8))
            container.background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.argb(alpha, 8, 15, 27))
                cornerRadius = dp(18).toFloat()
                setStroke(dp(1), Color.argb(175, 53, 208, 177))
            }
            if (attached) {
                try { window.updateViewLayout(container, params) } catch (_: Exception) { }
            }
        }

        fun show() {
            if (attached) return
            try { window.addView(container, params); attached = true } catch (_: Exception) { }
        }

        fun update(original: String, arabic: String, state: String) {
            mainHandler.post {
                status.text = "لسان • $state"
                // Status-only updates must not erase the last subtitle prematurely.
                if (original.isBlank() && arabic.isBlank()) return@post
                source.text = original
                translated.text = arabic
                hideRunnable?.let(mainHandler::removeCallbacks)
                val expectedSource = original
                val expectedArabic = arabic
                val hide = Runnable {
                    if (source.text.toString() == expectedSource &&
                        translated.text.toString() == expectedArabic) {
                        source.text = ""
                        translated.text = ""
                    }
                }
                hideRunnable = hide
                mainHandler.postDelayed(hide, 6_000L)
            }
        }

        fun close() {
            hideRunnable?.let(mainHandler::removeCallbacks)
            hideRunnable = null
            if (attached) {
                try { window.removeView(container) } catch (_: Exception) { }
                attached = false
            }
        }
    }

}
