# Third-party notices

- Vosk Android runtime (`com.alphacephei:vosk-android`) is distributed by Alpha Cephei. The Turkish small model is listed by Vosk under Apache License 2.0. See https://alphacephei.com/vosk/models and https://alphacephei.com/vosk/install.
- Google ML Kit Translation (`com.google.mlkit:translate`) is a Google SDK. Its language model is downloaded on demand by the SDK. See https://developers.google.com/ml-kit/language/translation/android.

No third-party model binary is bundled in this source archive.


## Groq API (اختياري)

يستدعي التطبيق Whisper Large V3 عبر نقطة Groq Speech-to-Text، وQwen 3.8 27B عبر نقطة Chat Completions عند إضافة المستخدم مفتاح Groq API الخاص به. تخضع الخدمة لشروط Groq وحصص الاستخدام وسياسة الخصوصية الخاصة بها. لا تُضمّن أي مفاتيح API في التطبيق؛ يُدخل المستخدم مفتاحه ويحفظه التطبيق مشفّراً محلياً. يظل بإمكان التطبيق استخدام Vosk وGoogle ML Kit محلياً عند عدم توفر الخدمة السحابية.
