package com.lisanlive.app

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    companion object {
        private const val REQUEST_AUDIO = 8101
        private const val REQUEST_PROJECTION = 8102
        private const val REQUEST_OVERLAY = 8103
        private const val REQUEST_IMPORT_MODEL = 8104
    }

    private val bg = Color.rgb(7, 13, 23)
    private val panel = Color.rgb(16, 27, 43)
    private val panelAlt = Color.rgb(21, 36, 55)
    private val teal = Color.rgb(65, 218, 184)
    private val tealDark = Color.rgb(16, 73, 68)
    private val white = Color.rgb(244, 248, 250)
    private val soft = Color.rgb(157, 177, 195)
    private val red = Color.rgb(218, 83, 99)

    private lateinit var contentHost: FrameLayout
    private lateinit var globalStatus: TextView
    private lateinit var modelButton: Button
    private lateinit var importButton: Button
    private lateinit var playbackButton: Button
    private lateinit var micButton: Button
    private lateinit var overlayButton: Button
    private lateinit var stopButton: Button
    private lateinit var pauseButton: Button
    private lateinit var modelProgress: ProgressBar
    private lateinit var modelInfo: TextView
    private lateinit var statusView: TextView
    private lateinit var sourceView: TextView
    private lateinit var translatedView: TextView
    private lateinit var historyView: TextView
    private lateinit var audioLevelBar: ProgressBar
    private lateinit var audioLevelInfo: TextView
    private lateinit var overlaySourceButton: Button

    private var pausedByUser = false
    private var sessionActive = false
    private var pendingMode = ""
    private var currentTranslation = ""
    private var receiverRegistered = false
    private var activeTab = "home"
    private var modelBusy = false
    private var subtitleFontSizeSp = 22
    private var subtitlePositionTop = false
    private var subtitleBackgroundLevel = 2
    private var overlayShowSource = true
    private var currentAudioLevel = 0
    private lateinit var subtitleSizeInfo: TextView
    private lateinit var subtitlePositionButton: Button
    private lateinit var subtitleBackgroundButton: Button

    private val updates = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != LiveTranslateService.ACTION_UPDATE) return
            val status = intent.getStringExtra("status").orEmpty()
            val source = intent.getStringExtra("source").orEmpty()
            val translated = intent.getStringExtra("translated").orEmpty()
            if (intent.hasExtra("audio_level")) updateAudioLevel(intent.getIntExtra("audio_level", 0))
            if (intent.hasExtra("active")) setSessionUi(intent.getBooleanExtra("active", false))
            if (intent.getBooleanExtra("stopped", false)) setSessionUi(false)
            if (status.isNotBlank()) {
                globalStatus.text = status
                if (::statusView.isInitialized) statusView.text = status
            }
            if (source.isNotBlank() && ::sourceView.isInitialized) sourceView.text = source
            if (translated.isNotBlank()) {
                currentTranslation = translated
                if (::translatedView.isInitialized) translatedView.text = translated
                refreshHistory()
            } else if (source.isNotBlank() && ::translatedView.isInitialized && translatedView.text.isNullOrBlank()) {
                translatedView.text = "يتم تجهيز الترجمة…"
            }
            val active = status.contains("يستمع") || status.contains("عاد الاستماع") || status.contains("ترجمة مباشرة")
            if (active || status.contains("متوقف مؤقتاً")) setSessionUi(true)
            if (status.contains("متوقف مؤقتاً")) {
                pausedByUser = true
                if (::pauseButton.isInitialized) pauseButton.text = "استئناف"
                updateAudioLevel(0)
            }
            if (status.contains("عاد الاستماع") || status.contains("يستمع")) {
                pausedByUser = false
                if (::pauseButton.isInitialized) pauseButton.text = "إيقاف مؤقت"
                updateAudioLevel(currentAudioLevel)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        loadSubtitleSettings()
        buildScreen()
        refreshModelUi()
        requestNotificationPermissionIfNeeded()
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(LiveTranslateService.ACTION_UPDATE)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(updates, filter, Context.RECEIVER_NOT_EXPORTED)
        else {
            @Suppress("DEPRECATION")
            registerReceiver(updates, filter)
        }
        receiverRegistered = true
        refreshModelUi()
    }

    override fun onResume() {
        super.onResume()
        refreshOverlayUi()
        refreshModelUi()
        // Ask the service for its real state; a saved preference can be stale after Android kills it.
        startService(Intent(this, LiveTranslateService::class.java).setAction(LiveTranslateService.ACTION_QUERY_STATUS))
    }

    override fun onStop() {
        if (receiverRegistered) {
            try { unregisterReceiver(updates) } catch (_: Exception) { }
            receiverRegistered = false
        }
        super.onStop()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            // Android 15 enforces edge-to-edge for apps targeting API 35.
            // Keep the header and bottom tabs out of the status/navigation bars.
            setOnApplyWindowInsetsListener { view, insets ->
                view.setPadding(
                    insets.systemWindowInsetLeft,
                    insets.systemWindowInsetTop,
                    insets.systemWindowInsetRight,
                    insets.systemWindowInsetBottom
                )
                insets
            }
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(16), dp(22), dp(12))
            setBackgroundColor(Color.rgb(9, 17, 29))
        }
        val brandRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val brandMark = text("ل", 25f, bg, true).apply {
            gravity = Gravity.CENTER
            background = rounded(teal, 15, teal, 0)
        }
        brandRow.addView(brandMark, LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginEnd = dp(11) })
        val brandWords = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val brand = text("LISAN LIVE", 21f, white, true).apply { letterSpacing = 0.10f; gravity = Gravity.START }
        brandWords.addView(brand, matchWidth())
        brandWords.addView(text("TURKISH  →  ARABIC", 9.5f, teal, true).apply {
            gravity = Gravity.START
            letterSpacing = 0.07f
        }, matchWidthWithTop(1))
        brandRow.addView(brandWords, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        brandRow.addView(text("LIVE AUDIO", 9f, teal, true).apply {
            background = rounded(tealDark, 20, tealDark, 0)
            setPadding(dp(10), dp(7), dp(10), dp(7))
            gravity = Gravity.CENTER
        })
        header.addView(brandRow, matchWidth())
        header.addView(text("لسان — ترجمة صوتية مباشرة من التركية إلى العربية", 14f, white, true), matchWidthWithTop(12))
        val statusPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(13), dp(10), dp(13), dp(10))
            background = rounded(panel, 14, Color.rgb(35, 57, 77), 1)
        }
        statusPanel.addView(text("حالة التطبيق", 9.5f, teal, true), matchWidth())
        globalStatus = text("جاهز. ثبّت نموذج التركية للبدء.", 11.5f, soft, false).apply {
            setPadding(0, dp(4), 0, 0)
            maxLines = 2
            setLineSpacing(dp(2).toFloat(), 1f)
        }
        statusPanel.addView(globalStatus, matchWidth())
        header.addView(statusPanel, matchWidthWithTop(10))
        root.addView(header, matchWidth())

        contentHost = FrameLayout(this)
        root.addView(contentHost, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(buildBottomNavigation(), matchWidth())
        setContentView(root)
        root.requestApplyInsets()
        showTab("home")
    }

    private fun buildBottomNavigation(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        gravity = Gravity.CENTER
        setPadding(dp(6), dp(7), dp(6), dp(8))
        setBackgroundColor(Color.rgb(11, 20, 33))
        addNavItem(this, "home", "الرئيسية", "⌂")
        addNavItem(this, "live", "الترجمة", "◉")
        addNavItem(this, "history", "السجل", "▤")
        addNavItem(this, "guide", "الدليل", "i")
    }

    private fun addNavItem(bar: LinearLayout, key: String, label: String, symbol: String) {
        val item = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
            setPadding(dp(3), dp(6), dp(3), dp(6))
            background = if (activeTab == key) rounded(tealDark, 13, tealDark, 0) else null
            setOnClickListener { showTab(key) }
        }
        val icon = text(symbol, 19f, if (activeTab == key) teal else soft, true).apply { gravity = Gravity.CENTER }
        val caption = text(label, 10f, if (activeTab == key) teal else soft, activeTab == key).apply { gravity = Gravity.CENTER }
        item.addView(icon, matchWidth())
        item.addView(caption, matchWidthWithTop(1))
        bar.addView(item, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
    }

    private fun showTab(tab: String) {
        activeTab = tab
        if (!::contentHost.isInitialized) return
        contentHost.removeAllViews()
        val page = when (tab) {
            "live" -> buildLivePage()
            "history" -> buildHistoryPage()
            "guide" -> buildGuidePage()
            else -> buildHomePage()
        }
        contentHost.addView(page, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        // Rebuild only the fixed navigation row so the selected section is visibly highlighted.
        val root = contentHost.parent as? LinearLayout ?: return
        if (root.childCount >= 3) {
            root.removeViewAt(2)
            root.addView(buildBottomNavigation(), matchWidth())
        }
        refreshModelUi()
        refreshOverlayUi()
        setSessionUi(sessionActive)
    }

    private fun pageColumn(): Pair<ScrollView, LinearLayout> {
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            setBackgroundColor(bg)
        }
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(18), dp(18), dp(18), dp(24))
        }
        scroll.addView(column, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return scroll to column
    }

    private fun buildHomePage(): View {
        val (scroll, page) = pageColumn()
        page.addView(eyebrow("01  /  البداية"), matchWidth())
        page.addView(text("اسمع البث. وافهمه.", 26f, white, true), matchWidthWithTop(5))
        page.addView(text("ترجمة الكلام التركي المسموع من البثوث والمسلسلات إلى العربية مباشرة. لا يحتاج الفيديو إلى ترجمة مكتوبة.", 14f, soft, false).apply { setLineSpacing(dp(3).toFloat(), 1f) }, matchWidthWithTop(7))
        page.addView(space(17))

        val modelCard = card()
        modelCard.addView(text("تجهيز محرك التركية", 17f, white, true), matchWidth())
        modelInfo = text("يلزم تثبيت النموذج الصوتي مرة واحدة. يمكنك تنزيله أو اختيار ملف ZIP الذي سبق تنزيله إلى الهاتف.", 12.5f, soft, false).apply {
            gravity = Gravity.END
            setLineSpacing(dp(3).toFloat(), 1f)
        }
        modelCard.addView(modelInfo, matchWidthWithTop(7))
        modelProgress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            progressTintList = android.content.res.ColorStateList.valueOf(teal)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(40, 55, 72))
            visibility = View.GONE
        }
        modelCard.addView(modelProgress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(7)).apply { topMargin = dp(12) })
        modelButton = button("تنزيل نموذج التركية", teal, bg) { downloadModel() }
        modelCard.addView(modelButton, matchWidthWithTop(12))
        importButton = button("استيراد النموذج من التنزيلات", panelAlt, white) { chooseModelZip() }
        modelCard.addView(importButton, matchWidthWithTop(8))
        page.addView(modelCard, matchWidth())
        page.addView(space(14))

        val steps = card()
        steps.addView(eyebrow("02  /  بعد تثبيت النموذج"), matchWidth())
        steps.addView(text("ابدأ الترجمة من القسم السفلي", 17f, white, true), matchWidthWithTop(5))
        steps.addView(text("اختر التقاط صوت البث أو الفيديو مباشرة، أو استخدم ميكروفون الهاتف إذا كان التطبيق يمنع التقاط الصوت الداخلي. وافق على نافذة Android عند طلبها.", 12.5f, soft, false).apply { setLineSpacing(dp(3).toFloat(), 1f) }, matchWidthWithTop(7))
        val go = button("افتح شاشة الترجمة  ←", tealDark, teal) { showTab("live") }
        steps.addView(go, matchWidthWithTop(12))
        page.addView(steps, matchWidth())
        page.addView(space(14))
        page.addView(text("التطبيق يعالج الصوت فقط محلياً بعد تنزيل النموذجين؛ لا يقرأ الشاشة ولا يحتاج إلى ترجمة تركية مكتوبة.", 11f, soft, false).apply {
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
        }, matchWidth())
        return scroll
    }

    private fun buildLivePage(): View {
        val (scroll, page) = pageColumn()
        page.addView(eyebrow("02  /  مساحة الترجمة"), matchWidth())
        page.addView(text("الترجمة المباشرة", 25f, white, true), matchWidthWithTop(5))
        page.addView(text("يعتمد على الصوت التركي المسموع فقط؛ لا يحتاج إلى كتابة أو ترجمة على الفيديو.", 13f, soft, false), matchWidthWithTop(5))
        page.addView(space(14))

        val capture = card()
        capture.addView(text("طريقة الترجمة المباشرة", 16f, white, true), matchWidth())
        playbackButton = button("التقاط صوت البث أو المسلسل", teal, bg) { requestStart("playback") }
        capture.addView(playbackButton, matchWidthWithTop(12))
        capture.addView(text("يلتقط صوت البث أو المسلسل من داخل Android عندما يسمح التطبيق المصدر بالتقاطه؛ لا يحتاج الفيديو إلى ترجمة مكتوبة.", 11f, soft, false), matchWidthWithTop(4))
        micButton = button("الميكروفون — بديل صوتي", panelAlt, white) { requestStart("microphone") }
        capture.addView(micButton, matchWidthWithTop(10))
        capture.addView(text("عند منع الصوت الداخلي: شغّل البث على مكبر الهاتف واجعل الهاتف قريبًا منه. السماعات لا تناسب هذا الوضع.", 11f, soft, false), matchWidthWithTop(4))
        overlayButton = button("تفعيل الترجمة فوق الفيديو", panelAlt, white) { requestOverlayPermission() }
        capture.addView(overlayButton, matchWidthWithTop(10))
        page.addView(capture, matchWidth())
        page.addView(space(13))

        val live = card()
        live.addView(text("حالة الجلسة", 16f, white, true), matchWidth())
        statusView = text(globalStatus.text?.toString() ?: "جاهز. اختر طريقة الالتقاط بعد تثبيت النموذج.", 12f, teal, true).apply { setLineSpacing(dp(2).toFloat(), 1f) }
        live.addView(statusView, matchWidthWithTop(8))
        audioLevelInfo = text("إشارة الصوت: لم تبدأ بعد", 10.5f, soft, false)
        live.addView(audioLevelInfo, matchWidthWithTop(12))
        audioLevelBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = currentAudioLevel
            progressTintList = android.content.res.ColorStateList.valueOf(teal)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(39, 54, 72))
        }
        live.addView(audioLevelBar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(6)).apply {
            topMargin = dp(6)
        })
        live.addView(space(12))
        live.addView(text("الكلام التركي", 11f, soft, true), matchWidth())
        sourceView = text("سيظهر الكلام التركي هنا…", 14f, white, false).apply {
            setPadding(0, dp(6), 0, dp(12))
            gravity = Gravity.START
            textDirection = View.TEXT_DIRECTION_LTR
            setTextIsSelectable(true)
        }
        live.addView(sourceView, matchWidth())
        live.addView(separator(), matchWidth())
        live.addView(space(10))
        live.addView(text("الترجمة العربية", 11f, teal, true), matchWidth())
        translatedView = text("ستظهر الترجمة العربية هنا…", subtitleFontSizeSp.toFloat(), white, true).apply {
            textDirection = View.TEXT_DIRECTION_RTL
            gravity = Gravity.CENTER
            setLineSpacing(dp(4).toFloat(), 1.05f)
            setPadding(0, dp(7), 0, dp(12))
            setTextIsSelectable(true)
        }
        live.addView(translatedView, matchWidth())

        val appearance = card()
        appearance.addView(text("مظهر الترجمة فوق الفيديو", 15f, white, true), matchWidth())
        subtitleSizeInfo = text("حجم الخط: ${subtitleFontSizeSp}", 11.5f, soft, false)
        appearance.addView(subtitleSizeInfo, matchWidthWithTop(7))
        val sizeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        sizeRow.addView(button("A −  تصغير", panelAlt, white) { changeSubtitleFont(-2) },
            LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(5) })
        sizeRow.addView(button("A +  تكبير", panelAlt, white) { changeSubtitleFont(2) },
            LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(5) })
        appearance.addView(sizeRow, matchWidthWithTop(8))
        val styleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        subtitlePositionButton = button("الموضع: أسفل", panelAlt, white) { toggleSubtitlePosition() }
        subtitleBackgroundButton = button("الخلفية: داكنة", panelAlt, white) { cycleSubtitleBackground() }
        styleRow.addView(subtitlePositionButton, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(5) })
        styleRow.addView(subtitleBackgroundButton, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(5) })
        appearance.addView(styleRow, matchWidthWithTop(7))
        overlaySourceButton = button("الأصل التركي: ظاهر", panelAlt, white) { toggleOverlaySource() }
        appearance.addView(overlaySourceButton, matchWidthWithTop(7))
        appearance.addView(text("اسحب شريط (≡) أعلى النافذة لتحريكها. ويمكنك إخفاء الأصل التركي والاكتفاء بالعربية.", 11f, soft, false), matchWidthWithTop(7))
        page.addView(appearance, matchWidthWithTop(12))
        refreshSubtitleSettingsUi()
        loadLatestTranslationIntoLive()
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        pauseButton = button("إيقاف مؤقت", panelAlt, white) { togglePause() }.apply {
            isEnabled = false
            if (pausedByUser) text = "استئناف"
        }
        stopButton = button("إيقاف", red, white) { stopCapture() }.apply { isEnabled = false }
        controls.addView(pauseButton, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(5) })
        controls.addView(stopButton, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(5) })
        live.addView(controls, matchWidthWithTop(7))
        val copy = button("نسخ آخر ترجمة", panelAlt, white) { copyTranslation() }
        live.addView(copy, matchWidthWithTop(8))
        page.addView(live, matchWidth())
        return scroll
    }


    private fun loadSubtitleSettings() {
        val prefs = getSharedPreferences("lisan_display", MODE_PRIVATE)
        subtitleFontSizeSp = prefs.getInt("font_size", 22).coerceIn(16, 32)
        subtitlePositionTop = prefs.getBoolean("position_top", false)
        subtitleBackgroundLevel = prefs.getInt("background_level", 2).coerceIn(0, 2)
        overlayShowSource = prefs.getBoolean("show_source", true)
    }

    private fun refreshSubtitleSettingsUi() {
        if (::subtitleSizeInfo.isInitialized) subtitleSizeInfo.text = "حجم الخط: $subtitleFontSizeSp"
        if (::subtitlePositionButton.isInitialized) {
            subtitlePositionButton.text = if (subtitlePositionTop) "الموضع: أعلى" else "الموضع: أسفل"
        }
        if (::subtitleBackgroundButton.isInitialized) {
            subtitleBackgroundButton.text = "الخلفية: " + when (subtitleBackgroundLevel) {
                0 -> "خفيفة"
                1 -> "متوسطة"
                else -> "داكنة"
            }
        }
        if (::overlaySourceButton.isInitialized) {
            overlaySourceButton.text = "الأصل التركي: " + if (overlayShowSource) "ظاهر" else "مخفي"
        }
    }

    private fun persistSubtitleSettings(resetPosition: Boolean = false) {
        val editor = getSharedPreferences("lisan_display", MODE_PRIVATE).edit()
            .putInt("font_size", subtitleFontSizeSp)
            .putBoolean("position_top", subtitlePositionTop)
            .putInt("background_level", subtitleBackgroundLevel)
            .putBoolean("show_source", overlayShowSource)
        if (resetPosition) editor.remove("overlay_y")
        editor.apply()
        if (::translatedView.isInitialized) translatedView.textSize = subtitleFontSizeSp.toFloat()
        refreshSubtitleSettingsUi()
        if (sessionActive) {
            try {
                startService(Intent(this, LiveTranslateService::class.java)
                    .setAction(LiveTranslateService.ACTION_UPDATE_OVERLAY_SETTINGS))
            } catch (e: Exception) {
                globalStatus.text = "حُفظ مظهر الترجمة، لكن تعذّر تحديث النافذة الحالية: ${e.message ?: "خطأ"}"
            }
        }
    }

    private fun changeSubtitleFont(delta: Int) {
        subtitleFontSizeSp = (subtitleFontSizeSp + delta).coerceIn(16, 32)
        persistSubtitleSettings()
    }

    private fun toggleSubtitlePosition() {
        subtitlePositionTop = !subtitlePositionTop
        persistSubtitleSettings(resetPosition = true)
    }

    private fun cycleSubtitleBackground() {
        subtitleBackgroundLevel = (subtitleBackgroundLevel + 1) % 3
        persistSubtitleSettings()
    }

    private fun toggleOverlaySource() {
        overlayShowSource = !overlayShowSource
        persistSubtitleSettings()
    }

    private fun updateAudioLevel(level: Int) {
        currentAudioLevel = level.coerceIn(0, 100)
        if (::audioLevelBar.isInitialized) audioLevelBar.progress = currentAudioLevel
        if (::audioLevelInfo.isInitialized) {
            audioLevelInfo.text = when {
                !sessionActive -> "إشارة الصوت: لم تبدأ الجلسة"
                pausedByUser -> "الاستماع متوقف مؤقتاً"
                currentAudioLevel >= 12 -> "الصوت يصل بوضوح • ${currentAudioLevel}%"
                currentAudioLevel >= 1 -> "إشارة صوت منخفضة • ${currentAudioLevel}%"
                else -> "لا توجد إشارة صوت حالياً • 0%"
            }
            audioLevelInfo.setTextColor(if (sessionActive && !pausedByUser && currentAudioLevel >= 1) teal else soft)
        }
    }

    private fun loadLatestTranslationIntoLive() {
        val array = try {
            org.json.JSONArray(getSharedPreferences("lisan_live", MODE_PRIVATE).getString("history", "[]"))
        } catch (_: Exception) { org.json.JSONArray() }
        val latest = array.optJSONObject(0) ?: return
        val original = latest.optString("tr")
        val arabic = latest.optString("ar")
        if (original.isNotBlank()) sourceView.text = original
        if (arabic.isNotBlank()) {
            translatedView.text = arabic
            currentTranslation = arabic
        }
    }

    private fun buildHistoryPage(): View {
        val (scroll, page) = pageColumn()
        page.addView(eyebrow("03  /  المحفوظات"), matchWidth())
        page.addView(text("سجل الترجمات", 25f, white, true), matchWidthWithTop(5))
        page.addView(text("آخر الجمل التي تمت ترجمتها على هذا الهاتف.", 13f, soft, false), matchWidthWithTop(5))
        page.addView(space(14))
        val history = card()
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val clear = button("مسح الكل", red, white) { clearHistory() }
        header.addView(clear, LinearLayout.LayoutParams(dp(94), dp(42)))
        header.addView(text("الترجمة / الأصل", 15f, white, true).apply { gravity = Gravity.END }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        history.addView(header, matchWidth())
        historyView = text("لا توجد ترجمات محفوظة بعد.", 13f, soft, false).apply {
            setLineSpacing(dp(4).toFloat(), 1f)
            setTextIsSelectable(true)
        }
        history.addView(historyView, matchWidthWithTop(13))
        page.addView(history, matchWidth())
        refreshHistory()
        return scroll
    }

    private fun buildGuidePage(): View {
        val (scroll, page) = pageColumn()
        page.addView(eyebrow("04  /  المساعدة والإعدادات"), matchWidth())
        page.addView(text("كيف تستخدم لسان؟", 25f, white, true), matchWidthWithTop(5))
        page.addView(space(13))
        val guide = card()
        addGuideStep(guide, "1", "ثبّت نموذج التركية", "من الرئيسية اختر التنزيل، أو استورد ملف vosk-model-small-tr-0.3.zip من مجلد التنزيلات.")
        addGuideStep(guide, "2", "اختر طريقة الترجمة", "التقط صوت البث أو الفيديو مباشرة. إذا منع التطبيق التقاط الصوت الداخلي، استخدم ميكروفون الهاتف مع مكبر الصوت.")
        addGuideStep(guide, "3", "فعّل الترجمة العائمة", "اسمح للسان بالظهور فوق التطبيقات الأخرى حتى ترى الترجمة وأنت تشاهد الفيديو.")
        addGuideStep(guide, "4", "ابدأ المشاهدة", "ابدأ التقاط صوت التطبيق من لسان، ارجع إلى البث المباشر أو المسلسل، وانتظر حتى تظهر الترجمة العربية. لا تحتاج إلى ترجمة تركية مكتوبة على الفيديو.")
        page.addView(guide, matchWidth())
        page.addView(space(13))
        val notes = card()
        notes.addView(text("ملاحظات مهمة", 16f, white, true), matchWidth())
        notes.addView(text("• بعض تطبيقات البث تمنع التقاط الصوت الداخلي؛ عندها استخدم الميكروفون مع مكبر الهاتف.\n\n• تظهر الترجمة بعد اكتمال جزء قصير من الكلام، وليست ترجمة فورية لكل كلمة.\n\n• يلزم الإنترنت لأول تنزيل لنموذج التركية ونموذج الترجمة العربية. بعد تنزيلهما يمكن العمل محلياً.", 12.5f, soft, false).apply {
            setLineSpacing(dp(3).toFloat(), 1f)
        }, matchWidthWithTop(8))
        page.addView(notes, matchWidth())
        return scroll
    }

    private fun addGuideStep(card: LinearLayout, number: String, title: String, detail: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.TOP
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val badge = text(number, 17f, teal, true).apply { gravity = Gravity.CENTER }
        row.addView(badge, LinearLayout.LayoutParams(dp(36), dp(36)))
        val words = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        words.addView(text(title, 14f, white, true), matchWidth())
        words.addView(text(detail, 11.5f, soft, false).apply { setLineSpacing(dp(2).toFloat(), 1f) }, matchWidthWithTop(3))
        row.addView(words, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(8) })
        card.addView(row, matchWidthWithTop(13))
    }

    private fun downloadModel() {
        beginModelOperation("جارٍ تنزيل نموذج التركية…")
        ModelInstaller.download(this, { progress ->
            runOnUiThread { if (::modelProgress.isInitialized) modelProgress.progress = progress }
        }) { result -> runOnUiThread { finishModelOperation(result) } }
    }

    private fun chooseModelZip() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        try {
            startActivityForResult(intent, REQUEST_IMPORT_MODEL)
        } catch (e: Exception) {
            toast("تعذّر فتح تطبيق الملفات: ${e.message ?: "غير معروف"}")
        }
    }

    private fun beginModelOperation(message: String) {
        modelBusy = true
        if (::modelButton.isInitialized) {
            modelButton.isEnabled = false
            modelButton.text = "جارٍ تجهيز النموذج…"
        }
        if (::importButton.isInitialized) importButton.isEnabled = false
        if (::modelProgress.isInitialized) {
            modelProgress.progress = 0
            modelProgress.visibility = View.VISIBLE
        }
        globalStatus.text = message
        if (::modelInfo.isInitialized) modelInfo.text = "لا تغلق التطبيق أثناء نسخ الملف وفحصه."
    }

    private fun finishModelOperation(result: Result<java.io.File>) {
        modelBusy = false
        if (::modelButton.isInitialized) modelButton.isEnabled = true
        if (::importButton.isInitialized) importButton.isEnabled = true
        if (::modelProgress.isInitialized) modelProgress.visibility = View.GONE
        if (result.isSuccess) {
            globalStatus.text = "اكتمل تثبيت نموذج التركية. يمكنك بدء الترجمة."
            if (::modelInfo.isInitialized) modelInfo.text = "تم التحقق من ملفات النموذج وتثبيتها داخل التطبيق."
            if (::modelButton.isInitialized) {
                modelButton.text = "النموذج مثبت ✓"
                modelButton.isEnabled = false
            }
            if (::importButton.isInitialized) {
                importButton.text = "استيراد نموذج آخر"
                importButton.isEnabled = true
            }
            setCaptureButtonsEnabled(true)
            toast("تم تثبيت نموذج التركية بنجاح")
        } else {
            val reason = result.exceptionOrNull()?.message ?: "سبب غير معروف"
            globalStatus.text = "فشل تجهيز النموذج: $reason"
            if (::modelInfo.isInitialized) modelInfo.text = "سبب الفشل: $reason\nيمكنك التأكد من اختيار ملف ZIP الصحيح أو تجربة التنزيل."
            if (::modelButton.isInitialized) modelButton.text = "إعادة محاولة التنزيل"
            toast("لم يتم تثبيت النموذج. راجع سبب الفشل في الرئيسية.")
        }
        refreshModelUi()
    }

    private fun refreshModelUi() {
        if (modelBusy) return
        val ready = ModelInstaller.isInstalled(this)
        if (ready) {
            if (::modelButton.isInitialized) {
                modelButton.text = "النموذج مثبت ✓"
                modelButton.isEnabled = false
            }
            if (::modelInfo.isInitialized) modelInfo.text = "تم تثبيت نموذج التعرف على الكلام. سيُجهّز نموذج الترجمة العربية عند أول تشغيل."
            setCaptureButtonsEnabled(true)
        } else {
            if (::modelButton.isInitialized && modelButton.text != "جارٍ تجهيز النموذج…") {
                modelButton.text = "تنزيل نموذج التركية"
                modelButton.isEnabled = true
            }
            if (::modelInfo.isInitialized && !modelInfo.text.toString().startsWith("سبب الفشل:")) {
                modelInfo.text = "يلزم تثبيت النموذج الصوتي مرة واحدة. يمكنك تنزيله أو استيراد ملف ZIP الموجود في التنزيلات."
            }
            setCaptureButtonsEnabled(false)
        }
    }

    private fun setCaptureButtonsEnabled(enabled: Boolean) {
        val usable = enabled && !sessionActive
        if (::playbackButton.isInitialized) playbackButton.isEnabled = usable
        if (::micButton.isInitialized) micButton.isEnabled = usable
    }

    private fun requestStart(mode: String) {
        if (!ModelInstaller.isInstalled(this)) {
            toast("ثبّت نموذج التركية من الرئيسية أولاً")
            showTab("home")
            return
        }
        if (sessionActive) {
            toast("هناك جلسة ترجمة تعمل بالفعل. أوقفها أولاً.")
            return
        }
        pendingMode = mode
        globalStatus.text = when (mode) {
            "playback" -> "سيطلب Android إذن مشاركة صوت التطبيق. هذا الإذن للصوت فقط، وليس لقراءة الصورة."
            else -> "سيطلب Android إذن الميكروفون. وافق ثم شغّل الفيديو بمكبر الهاتف."
        }
        val permissions = mutableListOf<String>()
        permissions.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val missing = permissions.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), REQUEST_AUDIO)
        else continueStart()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_AUDIO) {
            val audioGranted = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            if (!audioGranted) {
                val deniedMode = pendingMode
                pendingMode = ""
                setSessionUi(false)
                globalStatus.text = if (deniedMode == "playback") {
                    "لم يُمنح إذن التقاط الصوت. اسمح بالوصول إلى الصوت ثم أعد المحاولة."
                } else {
                    "لم يُمنح إذن الميكروفون. اسمح للسان باستخدامه ثم أعد المحاولة."
                }
                toast("يجب السماح بإذن الصوت لتشغيل هذا الوضع")
                return
            }
            continueStart()
        }
    }

    private fun continueStart() {
        try {
            when (pendingMode) {
                "playback" -> {
                    globalStatus.text = "بانتظار إذن Android لالتقاط صوت التطبيق فقط…"
                    val manager = getSystemService(MediaProjectionManager::class.java)
                    startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_PROJECTION)
                }
                "microphone" -> {
                    startForegroundService(Intent(this, LiveTranslateService::class.java)
                        .setAction(LiveTranslateService.ACTION_START_MIC))
                    setSessionUi(true)
                    globalStatus.text = "يتم تشغيل وضع الميكروفون…"
                }
            }
        } catch (e: Exception) {
            pendingMode = ""
            setSessionUi(false)
            globalStatus.text = "تعذّر بدء الالتقاط: ${e.message ?: "تحقق من الأذونات ثم أعد المحاولة"}"
            toast(globalStatus.text.toString())
        }
    }

    @Deprecated("Android activity result API used for system capture and document picker")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQUEST_IMPORT_MODEL -> {
                val uri = if (resultCode == RESULT_OK) data?.data else null
                if (uri != null) {
                    try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
                    beginModelOperation("جارٍ استيراد ملف النموذج من الهاتف…")
                    ModelInstaller.importZip(this, uri, { progress ->
                        runOnUiThread { if (::modelProgress.isInitialized) modelProgress.progress = progress }
                    }) { result -> runOnUiThread { finishModelOperation(result) } }
                }
            }
            REQUEST_PROJECTION -> {
                if (resultCode == RESULT_OK && data != null) {
                    try {
                        val serviceIntent = Intent(this, LiveTranslateService::class.java)
                            .setAction(LiveTranslateService.ACTION_START_PLAYBACK)
                            .putExtra(LiveTranslateService.EXTRA_RESULT_CODE, resultCode)
                            .putExtra(LiveTranslateService.EXTRA_PROJECTION_DATA, data)
                        startForegroundService(serviceIntent)
                        sessionActive = true
                        setSessionUi(true)
                        globalStatus.text = "يتم تشغيل التقاط صوت التطبيق…"
                    } catch (e: Exception) {
                        globalStatus.text = "تعذّر بدء التقاط صوت التطبيق: ${e.message ?: "خطأ غير معروف"}"
                        setSessionUi(false)
                        toast(globalStatus.text.toString())
                    }
                } else {
                    setSessionUi(false)
                    globalStatus.text = "لم تمنح إذن التقاط صوت التطبيق. يمكنك تجربة الميكروفون كبديل صوتي."
                    toast("لم يتم منح إذن التقاط صوت التطبيق")
                }
            }
            REQUEST_OVERLAY -> {
                refreshOverlayUi()
                if (Settings.canDrawOverlays(this)) {
                    if (sessionActive) {
                        startService(Intent(this, LiveTranslateService::class.java)
                            .setAction(LiveTranslateService.ACTION_REFRESH_OVERLAY))
                    }
                    toast("تم السماح بظهور الترجمة فوق الفيديو")
                }
            }
        }
    }

    private fun requestOverlayPermission() {
        if (Settings.canDrawOverlays(this)) {
            if (sessionActive) {
                try {
                    startService(Intent(this, LiveTranslateService::class.java)
                        .setAction(LiveTranslateService.ACTION_REFRESH_OVERLAY))
                    toast("تم تحديث نافذة الترجمة العائمة")
                } catch (e: Exception) {
                    toast("تعذّر تحديث الترجمة العائمة: ${e.message ?: "خطأ"}")
                }
            } else {
                toast("الإذن جاهز. ابدأ جلسة ترجمة لتظهر فوق الفيديو.")
            }
            refreshOverlayUi()
            return
        }
        val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        startActivityForResult(intent, REQUEST_OVERLAY)
    }

    private fun refreshOverlayUi() {
        if (!::overlayButton.isInitialized) return
        overlayButton.text = if (Settings.canDrawOverlays(this)) "إذن الترجمة العائمة جاهز ✓" else "السماح بالترجمة فوق الفيديو"
    }

    private fun setSessionUi(active: Boolean) {
        sessionActive = active
        val installed = ModelInstaller.isInstalled(this)
        if (::stopButton.isInitialized) stopButton.isEnabled = active
        if (::pauseButton.isInitialized) pauseButton.isEnabled = active
        if (::playbackButton.isInitialized) playbackButton.isEnabled = !active && installed
        if (::micButton.isInitialized) micButton.isEnabled = !active && installed
        if (!active) {
            pausedByUser = false
            if (::pauseButton.isInitialized) pauseButton.text = "إيقاف مؤقت"
            updateAudioLevel(0)
        }
    }

    private fun togglePause() {
        if (!sessionActive) return
        val action = if (pausedByUser) LiveTranslateService.ACTION_RESUME else LiveTranslateService.ACTION_PAUSE
        startService(Intent(this, LiveTranslateService::class.java).setAction(action))
        pausedByUser = !pausedByUser
        if (::pauseButton.isInitialized) pauseButton.text = if (pausedByUser) "استئناف" else "إيقاف مؤقت"
    }

    private fun stopCapture() {
        startService(Intent(this, LiveTranslateService::class.java).setAction(LiveTranslateService.ACTION_STOP))
        globalStatus.text = "تم إيقاف الترجمة."
        setSessionUi(false)
    }

    private fun copyTranslation() {
        if (currentTranslation.isBlank()) {
            toast("لا توجد ترجمة لنسخها بعد")
            return
        }
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Lisan Arabic translation", currentTranslation))
        toast("تم نسخ الترجمة")
    }

    private fun refreshHistory() {
        if (!::historyView.isInitialized) return
        val array = try {
            org.json.JSONArray(getSharedPreferences("lisan_live", MODE_PRIVATE).getString("history", "[]"))
        } catch (_: Exception) { org.json.JSONArray() }
        if (array.length() == 0) {
            historyView.text = "لا توجد ترجمات محفوظة بعد."
            return
        }
        val latest = array.optJSONObject(0)
        if (latest != null) currentTranslation = latest.optString("ar", currentTranslation)
        val builder = StringBuilder()
        for (i in 0 until minOf(array.length(), 40)) {
            val item = array.optJSONObject(i) ?: continue
            if (i > 0) builder.append("\n\n────────────────\n\n")
            builder.append(item.optString("ar"))
            builder.append("\n")
            builder.append(item.optString("tr"))
        }
        historyView.text = builder.toString()
    }

    private fun clearHistory() {
        getSharedPreferences("lisan_live", MODE_PRIVATE).edit().remove("history").apply()
        currentTranslation = ""
        refreshHistory()
        toast("تم مسح سجل الترجمات")
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 9001)
        }
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = rounded(panel, 20, Color.rgb(34, 55, 76), 1)
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.END
        textDirection = View.TEXT_DIRECTION_FIRST_STRONG
    }

    private fun eyebrow(value: String): TextView = text(value, 10f, teal, true).apply { letterSpacing = 0.08f }

    private fun button(label: String, color: Int, textColor: Int, action: () -> Unit): Button = Button(this).apply {
        text = label
        setTextColor(textColor)
        textSize = 13.5f
        isAllCaps = false
        typeface = Typeface.DEFAULT_BOLD
        minHeight = dp(48)
        background = rounded(color, 13, color, 0)
        setPadding(dp(12), dp(7), dp(12), dp(7))
        setOnClickListener { action() }
    }

    private fun rounded(color: Int, radiusDp: Int, strokeColor: Int, strokeDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
            if (strokeDp > 0) setStroke(dp(strokeDp), strokeColor)
        }

    private fun separator(): View = View(this).apply { setBackgroundColor(Color.rgb(46, 65, 84)) }
    private fun space(height: Int): View = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }
    private fun matchWidth(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun matchWidthWithTop(top: Int): LinearLayout.LayoutParams = matchWidth().apply { topMargin = dp(top) }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
