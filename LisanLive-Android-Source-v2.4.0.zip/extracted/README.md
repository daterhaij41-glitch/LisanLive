# LisanLive 2.4.0 — Turkish-to-Arabic Audio Translator

LisanLive is an Android app for translating **spoken Turkish audio** from livestreams, creators' streams, and TV/series playback into Arabic subtitles while the source video keeps playing. It does not read the screen, use OCR, or depend on Turkish captions.

## Features

- Android internal playback-audio capture when the source app permits it.
- Microphone fallback for apps that block internal playback capture. Use the phone speaker; headphones are unsuitable for this fallback.
- On-device Turkish speech recognition with Vosk.
- Turkish-to-Arabic translation with Google ML Kit after its translation model is downloaded.
- Movable floating Arabic captions over other apps.
- Controls for font size, overlay position, background opacity, and optional Turkish source text.
- A live audio-level meter and a silence warning to distinguish a blocked/silent capture stream from a recognition problem.
- Local history of the latest 40 translated segments.
- Pause, resume, stop, and model ZIP import/download.

## Android playback-capture limitation

Android only lets an app capture playback audio when the source app/audio stream meets the platform's playback-capture rules. Some apps or protected content block capture. If the audio meter stays at zero, stop the playback-capture session and try the microphone fallback with the phone speaker.

The Android permission prompt may use screen-sharing/recording wording because playback capture uses MediaProjection. LisanLive records audio through `AudioRecord`; it does not create a virtual display, capture screen frames, or run OCR.

## First run

1. Install the Turkish Vosk model from within the app, or import the previously downloaded `vosk-model-small-tr-0.3.zip`.
2. On first use, allow ML Kit to download its Turkish-to-Arabic translation model.
3. Grant overlay permission to show Arabic subtitles over the video.
4. Choose internal playback capture. If no audio reaches the meter, stop and use the microphone fallback with the phone speaker.

## Known limits

- Captions appear after a speech segment is recognized and translated, so a short delay is expected.
- Vosk small Turkish has limited accuracy, especially with dialects, names, music, noise, and overlapping voices. This release improves the app workflow and diagnostics; it does not claim a new recognition or translation engine.
- The first ML Kit translation-model download needs an internet connection. After downloading, translation can run on-device.
- Background execution can be restricted by device battery policies. On Infinix/XOS, allow LisanLive to run in the background and use an unrestricted battery setting where available.
- The app does not save raw audio recordings. Text history remains locally on the device and can be cleared in the app.

## Build

Requirements: JDK 17, Android SDK Platform 35, Gradle 8.13.

```bash
gradle --no-daemon --stacktrace --console=plain :app:assembleDebug
```

The debug APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

## Libraries

- Vosk Android `com.alphacephei:vosk-android:0.3.75`
- Google ML Kit Translation `com.google.mlkit:translate:17.0.3`

The Vosk acoustic model is not bundled in the APK. It is downloaded or imported once into the app's private storage.
