# Third-party notices

- Vosk Android runtime (`com.alphacephei:vosk-android`) is distributed by Alpha Cephei. The Turkish small model is listed by Vosk under Apache License 2.0. See https://alphacephei.com/vosk/models and https://alphacephei.com/vosk/install.
- Google ML Kit Translation (`com.google.mlkit:translate`) is a Google SDK. Its language model is downloaded on demand by the SDK. See https://developers.google.com/ml-kit/language/translation/android.

No third-party model binary is bundled in this source archive.
