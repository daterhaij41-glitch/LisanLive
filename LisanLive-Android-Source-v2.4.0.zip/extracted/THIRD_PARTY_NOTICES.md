# Third-party notices

- Vosk Android runtime (`com.alphacephei:vosk-android`) is distributed by Alpha Cephei. The Turkish small model is listed by Vosk under Apache License 2.0. See https://alphacephei.com/vosk/models and https://alphacephei.com/vosk/install.
- Google ML Kit Translation (`com.google.mlkit:translate`) is a Google SDK. Its language model is downloaded on demand by the SDK. See https://developers.google.com/ml-kit/language/translation/android.

No third-party model binary is bundled in this source archive.

- whisper.cpp v1.9.5 is used as the native on-device ASR engine. See https://github.com/ggml-org/whisper.cpp and its MIT license.
- Turkish Whisper Large-v3 General Q5_0 model weights are from turkmedstt/whisper-large-v3-turkish-general, repackaged by JoaoZaokk for whisper.cpp; Apache License 2.0. Model SHA-256: d4c8894a0c46c0ee5ef067ae981b415c7683721c52b2bc54308895a8f7f240eb. See https://huggingface.co/JoaoZaokk/whisper-large-v3-turkish-general-ggml.
